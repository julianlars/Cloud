const { app, BrowserWindow, Tray, Menu, nativeImage, shell, dialog } = require('electron');
const path = require('path');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const http = require('http');

let mainWindow = null;
let tray = null;
let backendProcess = null;
let isQuitting = false;
let isCompactMode = true;

const BACKEND_PORT = process.env.PORT || 3000;
const BACKEND_URL = `http://127.0.0.1:${BACKEND_PORT}`;

// Determine if we're running in a packaged app
const isPacked = app.isPackaged;

// Paths - handle both development and packaged scenarios
function getResourcePath(...segments) {
  if (isPacked) {
    // In packaged app without asar, files are directly in resources/app/
    return path.join(process.resourcesPath, 'app', ...segments);
  }
  // In development
  return path.join(__dirname, '..', ...segments);
}

// Alias for compatibility (same as getResourcePath when asar is disabled)
function getUnpackedPath(...segments) {
  return getResourcePath(...segments);
}

// User data path (writable) - stores config, etc.
const USER_DATA_PATH = app.getPath('userData');
const CONFIG_DIR = path.join(USER_DATA_PATH, 'data');
const CONFIG_PATH = path.join(CONFIG_DIR, 'config.json');

// Ensure config directory exists and copy default config if needed
function ensureConfigDir() {
  if (!fs.existsSync(CONFIG_DIR)) {
    fs.mkdirSync(CONFIG_DIR, { recursive: true });
  }
  
  // Copy default config if it doesn't exist
  if (!fs.existsSync(CONFIG_PATH)) {
    const defaultConfigPath = getUnpackedPath('backend', 'data', 'config.json');
    if (fs.existsSync(defaultConfigPath)) {
      fs.copyFileSync(defaultConfigPath, CONFIG_PATH);
      console.log('[main] Copied default config to:', CONFIG_PATH);
    }
  }
}

const BACKEND_ENTRY = getUnpackedPath('backend', 'src', 'index.js');
const BACKEND_CWD = getUnpackedPath('backend');

// Wait for backend to be ready
function waitForBackend(maxAttempts = 30) {
  return new Promise((resolve, reject) => {
    let attempts = 0;
    
    const check = () => {
      attempts++;
      console.log(`[main] Checking if backend is ready (attempt ${attempts}/${maxAttempts})...`);
      
      const req = http.get(`${BACKEND_URL}/api/health`, (res) => {
        if (res.statusCode === 200) {
          console.log('[main] Backend is ready!');
          resolve();
        } else {
          retry();
        }
      });
      
      req.on('error', () => {
        retry();
      });
      
      req.setTimeout(1000, () => {
        req.destroy();
        retry();
      });
    };
    
    const retry = () => {
      if (attempts >= maxAttempts) {
        reject(new Error('Backend failed to start'));
      } else {
        setTimeout(check, 500);
      }
    };
    
    check();
  });
}

// ---- Backend process management ----
function checkNodeInstalled() {
  try {
    const version = execSync('node --version', { encoding: 'utf8' }).trim();
    console.log('[main] Node.js version:', version);
    return version;
  } catch (error) {
    console.error('[main] Node.js not found:', error.message);
    return null;
  }
}

function startBackend() {
  if (backendProcess) {
    return;
  }

  // Check if Node.js is installed
  const nodeVersion = checkNodeInstalled();
  if (!nodeVersion) {
    dialog.showErrorBox(
      'Node.js Not Found',
      'Node.js is required but not installed or not in PATH.\n\n' +
      'Please install Node.js from https://nodejs.org/ and restart the app.'
    );
    return;
  }

  ensureConfigDir();

  console.log('[main] ====== STARTING BACKEND ======');
  console.log('[main] isPacked:', isPacked);
  console.log('[main] resourcesPath:', process.resourcesPath);
  console.log('[main] Backend entry:', BACKEND_ENTRY);
  console.log('[main] Backend CWD:', BACKEND_CWD);
  console.log('[main] Config path:', CONFIG_PATH);
  console.log('[main] Backend entry exists:', fs.existsSync(BACKEND_ENTRY));
  console.log('[main] Backend CWD exists:', fs.existsSync(BACKEND_CWD));
  
  // Check for node_modules in backend
  const nodeModulesPath = path.join(BACKEND_CWD, 'node_modules');
  console.log('[main] node_modules path:', nodeModulesPath);
  console.log('[main] node_modules exists:', fs.existsSync(nodeModulesPath));

  if (!fs.existsSync(BACKEND_ENTRY)) {
    dialog.showErrorBox(
      'Backend Not Found',
      `Backend entry file not found:\n${BACKEND_ENTRY}\n\n` +
      'The application may not be installed correctly.'
    );
    return;
  }

  if (!fs.existsSync(nodeModulesPath)) {
    dialog.showErrorBox(
      'Dependencies Not Found', 
      `Backend node_modules not found:\n${nodeModulesPath}\n\n` +
      'The application may not be installed correctly.'
    );
    return;
  }

  // Use system Node.js
  const nodeExecutable = 'node';
  let nodePath = nodeExecutable;
  
  // Check if we have a bundled node
  const bundledNodePath = isPacked 
    ? path.join(process.resourcesPath, process.platform === 'win32' ? 'node.exe' : 'node')
    : null;
    
  if (bundledNodePath && fs.existsSync(bundledNodePath)) {
    nodePath = bundledNodePath;
    console.log('[main] Using bundled Node.js:', nodePath);
  } else {
    console.log('[main] Using system Node.js');
  }

  // Spawn the backend
  backendProcess = spawn(nodePath, [BACKEND_ENTRY], {
    cwd: BACKEND_CWD,
    env: {
      ...process.env,
      NODE_ENV: 'production',
      PORT: String(BACKEND_PORT),
      CONFIG_PATH: CONFIG_PATH
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
    detached: false,
    shell: false
  });

  backendProcess.stdout?.on('data', (data) => {
    console.log('[backend]', data.toString().trim());
  });

  backendProcess.stderr?.on('data', (data) => {
    console.error('[backend]', data.toString().trim());
  });

  backendProcess.on('error', (error) => {
    console.error('[main] Failed to start backend:', error.message);
    backendProcess = null;
  });

  backendProcess.on('exit', (code, signal) => {
    console.log(`[backend] exited with code=${code} signal=${signal}`);
    backendProcess = null;
    if (!isQuitting) {
      // Auto-restart if backend crashes unexpectedly
      console.log('[main] Backend crashed, restarting in 3 seconds...');
      setTimeout(startBackend, 3000);
    }
  });
}

function stopBackend() {
  if (!backendProcess) return;
  try {
    if (process.platform === 'win32') {
      // On Windows, use taskkill to ensure the process tree is killed
      spawn('taskkill', ['/pid', backendProcess.pid, '/f', '/t'], { 
        detached: true,
        stdio: 'ignore'
      });
    } else {
      backendProcess.kill('SIGTERM');
    }
  } catch (e) {
    console.error('Failed to kill backend process:', e);
  } finally {
    backendProcess = null;
  }
}

// ---- Window management ----
function createWindow() {
  const compactSize = { width: 380, height: 260 };
  const expandedSize = { width: 960, height: 640 };

  const initialSize = isCompactMode ? compactSize : expandedSize;

  mainWindow = new BrowserWindow({
    ...initialSize,
    minWidth: compactSize.width,
    minHeight: compactSize.height,
    show: false,
    autoHideMenuBar: true,
    frame: true,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    },
  });

  // Load from backend server URL (not file)
  console.log('[main] Loading URL:', BACKEND_URL);
  mainWindow.loadURL(BACKEND_URL);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    // Open DevTools in development or if there's an issue
    if (!isPacked) {
      mainWindow.webContents.openDevTools();
    }
  });

  mainWindow.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
    }
  });
  
  // Handle load failures
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
    console.error(`[main] Failed to load ${validatedURL}: ${errorDescription} (${errorCode})`);
    
    // Show error page
    mainWindow.loadURL(`data:text/html,
      <html>
        <head><title>Loading Error</title></head>
        <body style="font-family: system-ui; padding: 40px; background: #1a1a2e; color: #eee;">
          <h2>⚠️ Failed to connect to backend</h2>
          <p>Error: ${errorDescription} (${errorCode})</p>
          <p>URL: ${validatedURL}</p>
          <p>The backend server may not be running.</p>
          <p style="color: #888; font-size: 12px; margin-top: 20px;">
            Press Ctrl+Shift+I to open DevTools for more details.<br>
            Check if Node.js is installed and in your PATH.
          </p>
          <button onclick="location.href='${BACKEND_URL}'" style="margin-top: 20px; padding: 10px 20px; cursor: pointer;">
            Retry
          </button>
        </body>
      </html>
    `);
  });
  
  // Log when page finishes loading
  mainWindow.webContents.on('did-finish-load', () => {
    console.log('[main] Page finished loading');
  });
  
  // Log console messages from the renderer
  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[renderer] ${message}`);
  });
}

function toggleWindowSize() {
  if (!mainWindow) return;

  const compactSize = { width: 380, height: 260 };
  const expandedSize = { width: 960, height: 640 };

  isCompactMode = !isCompactMode;
  const targetSize = isCompactMode ? compactSize : expandedSize;
  mainWindow.setSize(targetSize.width, targetSize.height);
}

// ---- Tray integration ----
function createTray() {
  const iconPath = path.join(__dirname, 'icon.png');
  let trayIcon = nativeImage.createFromPath(iconPath);
  if (trayIcon.isEmpty()) {
    trayIcon = nativeImage.createEmpty();
  }

  tray = new Tray(trayIcon.resize({ width: 16, height: 16 }));
  tray.setToolTip('Anaakwad - Weather-Reactive Lighting for Hue');

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Show Anaakwad',
      click: () => {
        if (!mainWindow) {
          createWindow();
        }
        mainWindow.show();
        mainWindow.focus();
      },
    },
    {
      label: 'Toggle Mini / Expanded View',
      click: () => {
        if (mainWindow) {
          toggleWindowSize();
        }
      },
    },
    { type: 'separator' },
    {
      label: 'Pause Backend',
      click: () => {
        stopBackend();
      },
    },
    {
      label: 'Resume Backend',
      click: () => {
        startBackend();
      },
    },
    { type: 'separator' },
    {
      label: 'Open Config Folder',
      click: () => {
        shell.openPath(CONFIG_DIR);
      },
    },
    {
      label: 'Open DevTools',
      click: () => {
        if (mainWindow) {
          mainWindow.webContents.openDevTools();
        }
      },
    },
    { type: 'separator' },
    {
      label: 'Quit',
      click: () => {
        isQuitting = true;
        stopBackend();
        if (mainWindow) {
          mainWindow.destroy();
        }
        app.quit();
      },
    },
  ]);

  tray.setContextMenu(contextMenu);

  tray.on('double-click', () => {
    if (!mainWindow) {
      createWindow();
    }
    mainWindow.show();
    mainWindow.focus();
  });
}

// ---- App lifecycle ----
app.whenReady().then(async () => {
  console.log('[main] App ready, starting...');
  console.log('[main] App path:', app.getAppPath());
  console.log('[main] Resources path:', process.resourcesPath);
  console.log('[main] User data:', USER_DATA_PATH);
  
  startBackend();
  createTray();
  
  try {
    // Wait for backend to be ready before showing the window
    console.log('[main] Waiting for backend...');
    await waitForBackend();
    console.log('[main] Backend ready, creating window...');
    createWindow();
  } catch (error) {
    console.error('[main] Failed to start:', error.message);
    dialog.showErrorBox(
      'Backend Failed to Start',
      `The backend server failed to start within the timeout period.\n\n` +
      `Error: ${error.message}\n\n` +
      `Please check:\n` +
      `1. Node.js is installed (run "node --version" in cmd)\n` +
      `2. No other app is using port ${BACKEND_PORT}\n\n` +
      `The app will try to continue anyway.`
    );
    // Show window anyway - it will show the error page
    createWindow();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    } else if (mainWindow) {
      mainWindow.show();
    }
  });
});

app.on('before-quit', () => {
  isQuitting = true;
  stopBackend();
});

app.on('window-all-closed', (e) => {
  // On Windows, keep app running in tray even if all windows are closed
  e.preventDefault();
});

// Handle second instance
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });
}
