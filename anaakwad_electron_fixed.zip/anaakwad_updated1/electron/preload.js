
// Minimal preload in case you want to expose IPC later.
// For now, the React frontend talks to the backend via HTTP/WebSocket directly.
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('anaakwadDesktop', {
  // placeholder for future desktop-specific APIs
});
