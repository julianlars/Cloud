import axios from 'axios';

export class WeatherService {
  constructor(configStore) {
    this.configStore = configStore;
    this.currentWeather = null;
    this.lastFetch = null;
  }

  getCurrentWeather() {
    return this.currentWeather;
  }

  async fetchWeather() {
    const apiKey = this.configStore.get('weatherApiKey');
    const lat = this.configStore.get('latitude');
    const lon = this.configStore.get('longitude');
    const provider = this.configStore.get('weatherProvider') || 'openweathermap';

    if (!apiKey) {
      console.warn('Weather API key not configured');
      return null;
    }

    if (!lat || !lon) {
      console.warn('Location not configured');
      return null;
    }

    try {
      let weatherData;
      
      switch (provider) {
        case 'weatherapi':
          weatherData = await this.fetchWeatherAPI(apiKey, lat, lon);
          break;
        case 'openweathermap':
        default:
          weatherData = await this.fetchOpenWeatherMap(apiKey, lat, lon);
          break;
      }

      this.currentWeather = weatherData;
      this.lastFetch = Date.now();
      
      return weatherData;
    } catch (error) {
      console.error('Weather fetch error:', error.message);
      return this.currentWeather; // Return cached if available
    }
  }

  async fetchOpenWeatherMap(apiKey, lat, lon) {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather`,
      {
        params: {
          lat,
          lon,
          appid: apiKey,
          units: 'metric'
        },
        timeout: 10000
      }
    );

    const data = response.data;
    const weatherId = data.weather[0].id;
    const condition = this.normalizeWeatherCondition(weatherId, data);

    return {
      condition,
      raw: {
        id: weatherId,
        main: data.weather[0].main,
        description: data.weather[0].description,
        icon: data.weather[0].icon
      },
      temperature: data.main.temp,
      humidity: data.main.humidity,
      windSpeed: data.wind?.speed || 0,
      cloudiness: data.clouds?.all || 0,
      visibility: data.visibility || 10000,
      sunrise: data.sys?.sunrise ? data.sys.sunrise * 1000 : null,
      sunset: data.sys?.sunset ? data.sys.sunset * 1000 : null,
      timestamp: Date.now(),
      location: data.name
    };
  }

  async fetchWeatherAPI(apiKey, lat, lon) {
    const response = await axios.get(
      `https://api.weatherapi.com/v1/current.json`,
      {
        params: {
          key: apiKey,
          q: `${lat},${lon}`
        },
        timeout: 10000
      }
    );

    const data = response.data;
    const condition = this.normalizeWeatherAPICondition(data.current.condition.code, data);

    return {
      condition,
      raw: {
        code: data.current.condition.code,
        text: data.current.condition.text,
        icon: data.current.condition.icon
      },
      temperature: data.current.temp_c,
      humidity: data.current.humidity,
      windSpeed: data.current.wind_kph / 3.6, // Convert to m/s
      cloudiness: data.current.cloud,
      visibility: data.current.vis_km * 1000,
      sunrise: null,
      sunset: null,
      timestamp: Date.now(),
      location: data.location.name
    };
  }

  normalizeWeatherCondition(weatherId, data) {
    // Check for special time-based events first
    const now = Date.now();
    const sunrise = data.sys?.sunrise * 1000;
    const sunset = data.sys?.sunset * 1000;
    
    // Sunrise window: 30 min before to 30 min after
    if (sunrise && Math.abs(now - sunrise) < 30 * 60 * 1000) {
      return 'sunrise';
    }
    
    // Sunset window: 30 min before to 30 min after
    if (sunset && Math.abs(now - sunset) < 30 * 60 * 1000) {
      return 'sunset';
    }

    // OpenWeatherMap condition codes
    // https://openweathermap.org/weather-conditions
    
    // Group 2xx: Thunderstorm
    if (weatherId >= 200 && weatherId < 300) {
      return 'thunderstorm';
    }
    
    // Group 3xx: Drizzle
    if (weatherId >= 300 && weatherId < 400) {
      return 'rain';
    }
    
    // Group 5xx: Rain
    if (weatherId >= 500 && weatherId < 600) {
      return 'rain';
    }
    
    // Group 6xx: Snow
    if (weatherId >= 600 && weatherId < 700) {
      return 'snow';
    }
    
    // Group 7xx: Atmosphere (fog, mist, etc.)
    if (weatherId >= 700 && weatherId < 800) {
      if (weatherId === 781) return 'thunderstorm'; // Tornado
      return 'fog';
    }
    
    // Group 800: Clear
    if (weatherId === 800) {
      // Check if it's hot
      if (data.main.temp > 30) {
        return 'hot';
      }
      return 'clear';
    }
    
    // Group 80x: Clouds
    if (weatherId > 800 && weatherId < 900) {
      if (weatherId === 801) return 'clear'; // Few clouds
      return 'cloudy';
    }

    // Check wind separately
    if (data.wind?.speed > 10) { // > 10 m/s is considered windy
      return 'windy';
    }

    return 'clear';
  }

  normalizeWeatherAPICondition(code, data) {
    // WeatherAPI condition codes
    // Check for special events
    const temp = data.current.temp_c;
    
    if (temp > 35) return 'hot';
    
    // Sunny/Clear
    if (code === 1000) return 'clear';
    
    // Partly cloudy
    if (code === 1003) return 'clear';
    
    // Cloudy, Overcast
    if (code >= 1006 && code <= 1009) return 'cloudy';
    
    // Mist, Fog
    if (code >= 1030 && code <= 1135) return 'fog';
    
    // Rain, Drizzle
    if (code >= 1150 && code <= 1201) return 'rain';
    
    // Snow, Sleet
    if (code >= 1204 && code <= 1237) return 'snow';
    
    // Rain
    if (code >= 1240 && code <= 1246) return 'rain';
    
    // Snow
    if (code >= 1249 && code <= 1264) return 'snow';
    
    // Thunder
    if (code >= 1273 && code <= 1282) return 'thunderstorm';

    // Check wind
    if (data.current.wind_kph > 36) return 'windy'; // > 10 m/s

    return 'clear';
  }

  isNearSunrise() {
    if (!this.currentWeather?.sunrise) return false;
    const now = Date.now();
    return Math.abs(now - this.currentWeather.sunrise) < 30 * 60 * 1000;
  }

  isNearSunset() {
    if (!this.currentWeather?.sunset) return false;
    const now = Date.now();
    return Math.abs(now - this.currentWeather.sunset) < 30 * 60 * 1000;
  }

  getStormIntensity() {
    if (!this.currentWeather) return 0;
    const id = this.currentWeather.raw?.id;
    if (!id) return 0;

    // OpenWeatherMap thunderstorm intensity
    if (id >= 200 && id < 210) return 0.5; // Light
    if (id >= 210 && id < 220) return 0.8; // Storm
    if (id >= 220 && id < 230) return 1.0; // Heavy
    if (id >= 230 && id < 240) return 0.6; // Drizzle storm

    return 0;
  }
}
