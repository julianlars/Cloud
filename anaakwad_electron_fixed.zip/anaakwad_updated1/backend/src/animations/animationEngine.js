import { EventEmitter } from 'events';

export class AnimationEngine extends EventEmitter {
  constructor(hueService, configStore) {
    super();
    this.hueService = hueService;
    this.configStore = configStore;
    this.running = false;
    this.currentWeather = null;
    this.currentAnimation = null;
    this.animationLoop = null;
    this.frameTime = 50; // 50ms = 20fps
    this.animationState = {};
    this.startTime = 0;

    // Master brightness multiplier
    this.masterBrightness = this.configStore.get('masterBrightness') || 1.0;

    // Weather cycling state
    this.cycleMode = this.configStore.get('cycleMode') || 'static';
    this.customCycleDurationMs = this.configStore.get('customCycleDurationMs') || 60000;
    this.cycleConditions = [];
    this.currentConditionIndex = 0;
    this.lastCycleSwitch = 0;
  }

  setMasterBrightness(brightness) {
    this.masterBrightness = Math.max(0.05, Math.min(1, brightness));
    this.configStore.set('masterBrightness', this.masterBrightness);
  }

  setCycleSettings({ cycleMode, customDurationMs }) {
    if (cycleMode) {
      this.cycleMode = cycleMode;
      this.configStore.set('cycleMode', cycleMode);
    }
    if (typeof customDurationMs === 'number' && !Number.isNaN(customDurationMs)) {
      this.customCycleDurationMs = customDurationMs;
      this.configStore.set('customCycleDurationMs', customDurationMs);
    }
  }

  getCycleIntervalMs() {
    switch (this.cycleMode) {
      case '10s':
        return 10000;
      case '45s':
        return 45000;
      case '2m':
        return 120000;
      case '5m':
        return 300000;
      case 'custom':
        return this.customCycleDurationMs || 60000;
      case 'static':
      default:
        return null;
    }
  }

  updateCycleConditionsFromWeather(weather) {
    if (!weather) return;

    const baseCondition = weather.condition;
    const applicable = Array.isArray(weather.applicableConditions)
      ? weather.applicableConditions.filter(Boolean)
      : [];

    let list = applicable.length > 0 ? applicable : (baseCondition ? [baseCondition] : []);

    // Ensure unique ordering
    list = Array.from(new Set(list));

    if (list.length === 0) {
      this.cycleConditions = [];
      return;
    }

    this.cycleConditions = list;

    const currentCond = this.currentAnimation?.condition;
    if (!currentCond || !this.cycleConditions.includes(currentCond)) {
      this.currentConditionIndex = 0;
    } else {
      this.currentConditionIndex = this.cycleConditions.indexOf(currentCond);
    }

    if (!this.currentAnimation) {
      const initial = this.cycleConditions[this.currentConditionIndex] || baseCondition;
      if (initial) {
        this.transitionToWeather(initial);
        this.lastCycleSwitch = Date.now();
      }
    }
  }

  maybeAdvanceCycle() {
    const interval = this.getCycleIntervalMs();
    if (!interval) return; // static mode

    if (!this.cycleConditions || this.cycleConditions.length < 2) return;

    const now = Date.now();
    if (!this.lastCycleSwitch) {
      this.lastCycleSwitch = now;
      return;
    }
    if (now - this.lastCycleSwitch < interval) return;

    this.currentConditionIndex = (this.currentConditionIndex + 1) % this.cycleConditions.length;
    const nextCondition = this.cycleConditions[this.currentConditionIndex];
    if (nextCondition) {
      this.transitionToWeather(nextCondition);
      this.lastCycleSwitch = now;
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.startTime = Date.now();
    this.runLoop();
    console.log('Animation engine started');
  }

  stop() {
    this.running = false;
    if (this.animationLoop) {
      clearTimeout(this.animationLoop);
      this.animationLoop = null;
    }
    console.log('Animation engine stopped');
  }

  setWeather(weather) {
    this.currentWeather = weather || null;
    this.updateCycleConditionsFromWeather(this.currentWeather);

    // In static mode, always follow primary condition immediately
    if (this.cycleMode === 'static' && this.currentWeather?.condition) {
      this.transitionToWeather(this.currentWeather.condition);
      this.lastCycleSwitch = Date.now();
    }
  }

  transitionToWeather(condition) {
    const mapping = this.configStore.getWeatherMapping(condition);
    this.currentAnimation = {
      condition,
      mapping,
      startTime: Date.now(),
      phase: 0
    };
    
    // Reset animation state
    this.animationState = {
      phase: 0,
      colorIndex: 0,
      lightPhases: {},
      lastFlash: 0,
      flashCount: 0
    };

    this.emit('stateChange', {
      condition,
      animation: mapping.animation,
      palette: mapping.palette
    });

    console.log(`Transitioning to ${condition} with ${mapping.animation}`);
  }

  getCurrentAnimation() {
    if (!this.currentAnimation) return null;
    return {
      condition: this.currentAnimation.condition,
      animation: this.currentAnimation.mapping.animation,
      palette: this.currentAnimation.mapping.palette,
      running: this.running
    };
  }

  async runLoop() {
    if (!this.running) return;

    try {
      await this.tick();
    } catch (error) {
      console.error('Animation tick error:', error.message);
    }

    this.animationLoop = setTimeout(() => this.runLoop(), this.frameTime);
  }

  async tick() {
    // Handle weather-based cycling between applicable conditions
    this.maybeAdvanceCycle();

    if (!this.currentAnimation || !this.hueService.isConnected()) return;

    const lights = this.configStore.get('selectedLights') || [];
    if (lights.length === 0) return;

    const { animation, palette, intensity } = this.currentAnimation.mapping;
    const globalIntensity = this.configStore.get('animationIntensity') || 1.0;
    const effectiveIntensity = intensity * globalIntensity;
    
    // Apply master brightness to all light commands
    const masterBri = this.masterBrightness || 1.0;

    const elapsed = Date.now() - this.currentAnimation.startTime;

    switch (animation) {
      case 'rainPulse':
        await this.animateRainPulse(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'lightningFlash':
        await this.animateLightningFlash(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'snowDrift':
        await this.animateSnowDrift(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'cloudDrift':
        await this.animateCloudDrift(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'heatRipple':
        await this.animateHeatRipple(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'windSway':
        await this.animateWindSway(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'mistFade':
        await this.animateMistFade(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'sunriseRamp':
        await this.animateSunriseRamp(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'candleFlicker':
        await this.animateCandleFlicker(lights, palette, effectiveIntensity, elapsed, masterBri);
        break;
      case 'none':
      default:
        await this.animateStatic(lights, palette, effectiveIntensity, masterBri);
        break;
    }
  }

  // Easing functions
  easeInOut(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  smoothstep(t) {
    return t * t * (3 - 2 * t);
  }

  cosineEase(t) {
    return (1 - Math.cos(t * Math.PI)) / 2;
  }

  // Color utilities
  hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
      parseInt(result[1], 16),
      parseInt(result[2], 16),
      parseInt(result[3], 16)
    ] : [255, 255, 255];
  }

  lerpColor(color1, color2, t) {
    const rgb1 = this.hexToRgb(color1);
    const rgb2 = this.hexToRgb(color2);
    return [
      Math.round(rgb1[0] + (rgb2[0] - rgb1[0]) * t),
      Math.round(rgb1[1] + (rgb2[1] - rgb1[1]) * t),
      Math.round(rgb1[2] + (rgb2[2] - rgb1[2]) * t)
    ];
  }

  // Animation implementations

  async animateRainPulse(lights, palette, intensity, elapsed, masterBri = 1) {
    // 15-20 second breathing cycle
    const cycleTime = 17500; // 17.5s average
    const phase = (elapsed % cycleTime) / cycleTime;
    const breathValue = this.cosineEase(phase);
    
    // Base brightness oscillates between 40% and 80%
    const baseBrightness = 0.4 + breathValue * 0.4 * intensity;

    for (const lightId of lights) {
      // Add subtle random shimmer (raindrop effect)
      const shimmer = Math.random() > 0.95 ? -0.1 : 0;
      const brightness = Math.max(0.1, Math.min(1, (baseBrightness + shimmer) * masterBri));
      
      // Cycle through palette
      const colorPhase = ((elapsed / 5000) + parseInt(lightId) * 0.3) % palette.length;
      const colorIndex = Math.floor(colorPhase);
      const colorT = colorPhase - colorIndex;
      const color = this.lerpColor(
        palette[colorIndex],
        palette[(colorIndex + 1) % palette.length],
        colorT
      );

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 200
      });
    }
  }

  async animateLightningFlash(lights, palette, intensity, elapsed, masterBri = 1) {
    const state = this.animationState;
    
    // Check if we should trigger a flash
    const timeSinceLastFlash = elapsed - state.lastFlash;
    const flashInterval = 20000 + Math.random() * 40000; // 20-60 seconds between bursts
    
    if (timeSinceLastFlash > flashInterval && state.flashCount === 0) {
      state.flashCount = 1 + Math.floor(Math.random() * 3); // 1-3 flashes per burst
      state.lastFlash = elapsed;
    }

    // Handle flash sequence
    if (state.flashCount > 0) {
      const flashPhase = (elapsed - state.lastFlash) % 500;
      
      if (flashPhase < 150) {
        // Flash on (100-200ms)
        for (const lightId of lights) {
          await this.hueService.setLightState(lightId, {
            on: true,
            brightness: 1.0 * masterBri,
            color: { rgb: [255, 255, 255] },
            transitionTime: 0
          });
        }
      } else if (flashPhase < 300) {
        // Flash off
        const baseColor = this.hexToRgb(palette[0]);
        for (const lightId of lights) {
          await this.hueService.setLightState(lightId, {
            on: true,
            brightness: 0.3 * intensity * masterBri,
            color: { rgb: baseColor },
            transitionTime: 0
          });
        }
        if (flashPhase > 250) {
          state.flashCount--;
        }
      }
      return;
    }

    // Normal storm ambience with low-frequency brightness rumble
    const rumbleCycle = 8000;
    const rumblePhase = (elapsed % rumbleCycle) / rumbleCycle;
    const rumble = 0.3 + this.cosineEase(rumblePhase) * 0.2;

    for (const lightId of lights) {
      const colorIndex = parseInt(lightId) % palette.length;
      const color = this.hexToRgb(palette[colorIndex]);
      
      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: rumble * intensity * masterBri,
        color: { rgb: color },
        transitionTime: 500
      });
    }
  }

  async animateSnowDrift(lights, palette, intensity, elapsed, masterBri = 1) {
    // 30-45 second drift cycles
    const cycleTime = 37500;
    const phase = (elapsed % cycleTime) / cycleTime;
    
    for (let i = 0; i < lights.length; i++) {
      const lightId = lights[i];
      // Each light has offset phase for drift effect
      const lightPhase = (phase + i * 0.15) % 1;
      const driftValue = this.smoothstep(lightPhase);
      
      // Subtle shimmer like blowing snow
      const shimmer = Math.sin(elapsed / 500 + i * 2) * 0.03;
      
      // Brightness varies subtly
      const brightness = (0.6 + driftValue * 0.3 * intensity + shimmer) * masterBri;
      
      // Color transitions between ice blue and soft white
      const colorT = this.smoothstep(lightPhase);
      const color = this.lerpColor(palette[0], palette[palette.length - 1], colorT);

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: Math.max(0.2, Math.min(1, brightness)),
        color: { rgb: color },
        transitionTime: 1000
      });
    }
  }

  async animateCloudDrift(lights, palette, intensity, elapsed, masterBri = 1) {
    // Gentle slow fades with desaturation waves
    const cycleTime = 25000;
    
    for (let i = 0; i < lights.length; i++) {
      const lightId = lights[i];
      const phase = ((elapsed / cycleTime) + i * 0.2) % 1;
      const fadeValue = this.cosineEase(phase);
      
      // Desaturation wave
      const desatPhase = ((elapsed / 15000) + i * 0.1) % 1;
      const desaturation = 0.7 + this.cosineEase(desatPhase) * 0.3;
      
      const brightness = (0.4 + fadeValue * 0.3 * intensity) * masterBri;
      const colorIndex = Math.floor((phase * palette.length)) % palette.length;
      let color = this.hexToRgb(palette[colorIndex]);
      
      // Apply desaturation
      const gray = (color[0] + color[1] + color[2]) / 3;
      color = color.map(c => Math.round(c * desaturation + gray * (1 - desaturation)));

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 800
      });
    }
  }

  async animateHeatRipple(lights, palette, intensity, elapsed, masterBri = 1) {
    // 2-5% brightness oscillation with warm glow alternation
    const rippleCycle = 3000;
    
    for (let i = 0; i < lights.length; i++) {
      const lightId = lights[i];
      // Alternating phase for ripple effect
      const phase = ((elapsed / rippleCycle) + i * 0.5) % 1;
      const ripple = this.cosineEase(phase);
      
      // Brightness oscillates 2-5%
      const brightness = (0.75 + ripple * 0.05 * intensity) * masterBri;
      
      // Alternate between warm colors
      const colorPhase = ((elapsed / 8000) + i * 0.25) % palette.length;
      const colorIndex = Math.floor(colorPhase);
      const colorT = colorPhase - colorIndex;
      const color = this.lerpColor(
        palette[colorIndex],
        palette[(colorIndex + 1) % palette.length],
        this.smoothstep(colorT)
      );

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 300
      });
    }
  }

  async animateWindSway(lights, palette, intensity, elapsed, masterBri = 1) {
    // Sequential wave effect left → right → left
    const swayDuration = 4000;
    const phase = (elapsed % swayDuration) / swayDuration;
    
    for (let i = 0; i < lights.length; i++) {
      const lightId = lights[i];
      // Wave position based on light index
      const wavePosition = i / Math.max(1, lights.length - 1);
      
      // Calculate wave influence
      const waveFront = Math.abs(Math.sin(phase * Math.PI * 2)) ; // 0 to 1 back to 0
      const distanceFromWave = Math.abs(wavePosition - waveFront);
      const waveInfluence = Math.max(0, 1 - distanceFromWave * 3);
      
      const brightness = (0.5 + waveInfluence * 0.4 * intensity) * masterBri;
      
      // Color shifts with wave
      const colorPhase = (phase + wavePosition) % 1;
      const colorIndex = Math.floor(colorPhase * palette.length);
      const color = this.hexToRgb(palette[colorIndex % palette.length]);

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 200
      });
    }
  }

  async animateMistFade(lights, palette, intensity, elapsed, masterBri = 1) {
    // Ultra-slow breathing with low contrast
    const cycleTime = 45000; // 45 seconds
    const phase = (elapsed % cycleTime) / cycleTime;
    const breathValue = this.cosineEase(phase);
    
    // Very subtle brightness change
    const brightness = (0.25 + breathValue * 0.15 * intensity) * masterBri;
    
    for (const lightId of lights) {
      // Minimal color variation
      const colorIndex = parseInt(lightId) % palette.length;
      const color = this.hexToRgb(palette[colorIndex]);

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 2000
      });
    }
  }

  async animateSunriseRamp(lights, palette, intensity, elapsed, masterBri = 1) {
    // 3-4 minute smooth ramp through gradient
    const rampDuration = 3.5 * 60 * 1000; // 3.5 minutes
    const phase = Math.min(1, elapsed / rampDuration);
    
    // Progress through palette
    const colorProgress = this.smoothstep(phase) * (palette.length - 1);
    const colorIndex = Math.floor(colorProgress);
    const colorT = colorProgress - colorIndex;
    
    const color = this.lerpColor(
      palette[colorIndex],
      palette[Math.min(colorIndex + 1, palette.length - 1)],
      colorT
    );
    
    // Brightness ramps up
    const brightness = (0.2 + phase * 0.7 * intensity) * masterBri;

    for (const lightId of lights) {
      await this.hueService.setLightState(lightId, {
        on: true,
        brightness,
        color: { rgb: color },
        transitionTime: 1000
      });
    }
  }

  async animateCandleFlicker(lights, palette, intensity, elapsed, masterBri = 1) {
    // Candle-like flicker with randomized orange/amber shimmer
    // Duration: 3-5 minutes
    const flickerSpeed = 150;
    
    for (let i = 0; i < lights.length; i++) {
      const lightId = lights[i];
      
      // Perlin-like noise simulation for natural flicker
      const t = elapsed / flickerSpeed + i * 17;
      const flicker1 = Math.sin(t) * 0.5 + 0.5;
      const flicker2 = Math.sin(t * 1.7 + 3) * 0.5 + 0.5;
      const flicker3 = Math.sin(t * 2.3 + 7) * 0.5 + 0.5;
      const flickerValue = (flicker1 + flicker2 + flicker3) / 3;
      
      // Random larger flickers
      const randomFlicker = Math.random() > 0.9 ? Math.random() * 0.15 : 0;
      
      const brightness = (0.5 + flickerValue * 0.35 * intensity + randomFlicker) * masterBri;
      
      // Shift between orange and amber
      const colorPhase = flickerValue;
      const colorIndex = Math.floor(colorPhase * (palette.length - 1));
      const color = this.hexToRgb(palette[colorIndex]);

      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: Math.max(0.3, Math.min(1, brightness)),
        color: { rgb: color },
        transitionTime: 100
      });
    }
  }

  async animateStatic(lights, palette, intensity, masterBri = 1) {
    // No animation - stable light
    const color = this.hexToRgb(palette[0]);
    
    for (const lightId of lights) {
      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: 0.8 * intensity * masterBri,
        color: { rgb: color },
        transitionTime: 1000
      });
    }
  }

  // Preview a specific condition
  async previewCondition(condition, lights) {
    const mapping = this.configStore.getWeatherMapping(condition);
    const color = this.hexToRgb(mapping.palette[0]);
    
    for (const lightId of lights) {
      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: 0.8,
        color: { rgb: color },
        transitionTime: 500
      });
    }
  }

  // Manual scene override
  async applyManualScene(scene, lights) {
    const color = this.hexToRgb(scene.color);
    
    for (const lightId of lights) {
      this.hueService.setManualOverride(lightId, true);
      await this.hueService.setLightState(lightId, {
        on: true,
        brightness: scene.brightness || 0.8,
        color: { rgb: color },
        transitionTime: 500
      });
    }
  }
}
