import express from 'express';
import cors from 'cors';
import fs from 'fs';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Load environment variables
dotenv.config();
dotenv.config({ path: join(dirname(fileURLToPath(import.meta.url)), '../../.env') });

import { HueService } from './services/hueService.js';
import { WeatherService } from './services/weatherService.js';
import { AnimationEngine } from './animations/animationEngine.js';
import { ConfigStore } from './services/configStore.js';
import { setupRoutes } from './api/routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

// CORS
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());

// Initialize services
console.log('Initializing services...');
const configStore = new ConfigStore();
const hueService = new HueService(configStore);
const weatherService = new WeatherService(configStore);
const animationEngine = new AnimationEngine(hueService, configStore);

// WebSocket set
const clients = new Set();
wss.on('connection', (ws) => {
  clients.add(ws);
  console.log('WebSocket client connected');
  
  try {
    ws.send(JSON.stringify({
      type: 'state',
      data: {
        weatherMode: configStore.get('weatherMode') || false,
        currentWeather: weatherService.getCurrentWeather(),
        currentAnimation: animationEngine.getCurrentAnimation(),
        selectedLights: configStore.get('selectedLights') || [],
        bridgeConnected: hueService.isConnected()
      }
    }));
  } catch (error) {
    console.error('Failed to send initial state:', error);
  }

  ws.on('close', () => {
    clients.delete(ws);
    console.log('WebSocket client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    clients.delete(ws);
  });
});

// Broadcast helper
function broadcast(type, data) {
  const message = JSON.stringify({ type, data });
  clients.forEach(client => {
    try {
      if (client.readyState === 1) {
        client.send(message);
      }
    } catch (error) {
      console.error('Broadcast error:', error);
    }
  });
}

// Weather polling
let weatherInterval = null;
async function startWeatherPolling() {
  const poll = async () => {
    try {
      const weather = await weatherService.fetchWeather();
      if (weather) {
        broadcast('weather', weather);
        if (configStore.get('weatherMode')) {
          animationEngine.setWeather(weather);
          broadcast('animation', animationEngine.getCurrentAnimation());
        }
      }
    } catch (error) {
      console.error('Weather polling error:', error.message);
    }
  };
  
  await poll();
  weatherInterval = setInterval(poll, 60000);
}

function stopWeatherPolling() {
  if (weatherInterval) {
    clearInterval(weatherInterval);
    weatherInterval = null;
  }
}

// Routes
setupRoutes(app, {
  hueService,
  weatherService,
  animationEngine,
  configStore,
  broadcast,
  startWeatherPolling,
  stopWeatherPolling
});

// ======= FIXED FRONTEND PATH =======
const frontendDistPath = join(__dirname, '../../frontend/dist');
// This path resolves to: projectRoot/frontend/dist

console.log('Frontend dist path:', frontendDistPath);
console.log('Frontend dist exists:', fs.existsSync(frontendDistPath));
if (fs.existsSync(frontendDistPath)) {
  console.log('Frontend dist contents:', fs.readdirSync(frontendDistPath));
  const assetsPath = join(frontendDistPath, 'assets');
  if (fs.existsSync(assetsPath)) {
    console.log('Assets contents:', fs.readdirSync(assetsPath));
  }
}

app.use(express.static(frontendDistPath));

// Debug route to check paths
app.get('/api/debug/paths', (req, res) => {
  res.json({
    __dirname,
    frontendDistPath,
    frontendExists: fs.existsSync(frontendDistPath),
    frontendContents: fs.existsSync(frontendDistPath) ? fs.readdirSync(frontendDistPath) : [],
    cwd: process.cwd()
  });
});

app.get('*', (req, res) => {
  const indexPath = join(frontendDistPath, 'index.html');
  console.log('Serving index.html from:', indexPath, 'exists:', fs.existsSync(indexPath));
  res.sendFile(indexPath);
});

// Animation updates
animationEngine.on('stateChange', (state) => {
  broadcast('animationState', state);
});

// Init
async function init() {
  try {
    const bridgeIp = configStore.get('bridgeIp');
    const username = configStore.get('hueUsername');
    
    if (bridgeIp && username) {
      console.log(`Connecting to Hue bridge at ${bridgeIp}...`);
      await hueService.initialize();
      console.log('Hue initialized');
      startBridgeAutoReconnect();
    } else {
      console.log('Hue bridge not configured');
      startBridgeAutoReconnect();
    }
    
    if (configStore.get('weatherMode')) {
      console.log('Weather mode enabled — starting...');
      await startWeatherPolling();
      animationEngine.start();
    }
  } catch (error) {
    console.error('Initialization error:', error.message);
  }
}

// Server start
const PORT = process.env.BACKEND_PORT || process.env.PORT || 3000;

server.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║  Server running on http://0.0.0.0:${PORT}                       
║  WebSocket available on ws://0.0.0.0:${PORT}                     
╚══════════════════════════════════════════════════════════════╝
  `);
  
  init();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down...');
  animationEngine.stop();
  stopWeatherPolling();
  if (bridgeReconnectInterval) clearInterval(bridgeReconnectInterval);
  server.close();
});

process.on('SIGINT', () => {
  console.log('Shutting down...');
  animationEngine.stop();
  stopWeatherPolling();
  if (bridgeReconnectInterval) clearInterval(bridgeReconnectInterval);
  server.close();
  process.exit(0);
});

// Crash-hold so CMD doesn't close
process.on('uncaughtException', (err) => {
  console.error("UNCAUGHT ERROR:", err);
  console.log("Press ENTER to exit.");
  process.stdin.resume();
});


let bridgeReconnectInterval = null;

function startBridgeAutoReconnect() {
  if (bridgeReconnectInterval) return;
  bridgeReconnectInterval = setInterval(async () => {
    try {
      const bridgeIp = configStore.get('bridgeIp');
      const username = configStore.get('hueUsername');
      if (bridgeIp && username && !hueService.isConnected()) {
        console.log('Attempting auto-reconnect to Hue bridge...');
        await hueService.initialize();
        broadcast('bridgeConnected', { connected: hueService.isConnected(), bridgeIp });
      }
    } catch (error) {
      console.error('Auto-reconnect to Hue bridge failed:', error.message);
    }
  }, 30000);
}

