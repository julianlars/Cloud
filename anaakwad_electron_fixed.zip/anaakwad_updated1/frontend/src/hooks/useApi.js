import { useCallback, useMemo } from 'react';

export function useApi() {
  // Detect when running inside Electron (file:// origin) and route API calls to local backend
  const baseUrl = window.location.protocol === 'file:' 
    ? 'http://127.0.0.1:3000' 
    : '';

  const request = useCallback(async (url, options = {}) => {
    const response = await fetch(baseUrl + url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(error.error || error.message || 'Request failed');
    }

    return response.json().catch(() => ({}));
  }, [baseUrl]);

  const get = useCallback((url) => request(url), [request]);

  const post = useCallback((url, data) => request(url, {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);

  const put = useCallback((url, data) => request(url, {
    method: 'PUT',
    body: JSON.stringify(data),
  }), [request]);

  const del = useCallback((url) => request(url, {
    method: 'DELETE',
  }), [request]);

  // Return stable reference to prevent re-renders
  return useMemo(() => ({ get, post, put, delete: del }), [get, post, put, del]);
}
