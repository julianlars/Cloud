import React, { useState, useEffect } from 'react';
import { X, Save, Key, MapPin, Wifi, Trash2, RefreshCw } from 'lucide-react';
import { useApi } from '../hooks/useApi';

export default function SettingsPanel({ onClose, config, onConfigUpdate }) {
  const [weatherApiKey, setWeatherApiKey] = useState('');
  const [weatherProvider, setWeatherProvider] = useState(config?.weatherProvider || 'openweathermap');
  const [latitude, setLatitude] = useState(config?.latitude || '');
  const [longitude, setLongitude] = useState(config?.longitude || '');
  const [bridgeIp, setBridgeIp] = useState(config?.bridgeIp || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const api = useApi();

  const hasApiKey = config?.weatherApiKey && config.weatherApiKey !== '';

  const handleSave = async () => {
    setSaving(true);
    try {
      // Save weather API key if provided
      if (weatherApiKey) {
        await api.post('/api/keys/weather', { 
          apiKey: weatherApiKey, 
          provider: weatherProvider 
        });
      }

      // Save location
      if (latitude && longitude) {
        await api.post('/api/location', { latitude, longitude });
      }

      // Refresh config
      const newConfig = await api.get('/api/config');
      onConfigUpdate(newConfig);

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleResetBridge = async () => {
    if (!confirm('This will disconnect your Hue bridge. Continue?')) return;
    
    try {
      await api.post('/api/config', { 
        bridgeIp: '', 
        hueUsername: '' 
      });
      const newConfig = await api.get('/api/config');
      onConfigUpdate(newConfig);
      onClose();
    } catch (error) {
      console.error('Failed to reset bridge:', error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-night-950/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Panel */}
      <div className="relative w-full max-w-lg glass-panel p-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-display font-bold text-white">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-night-800/60 border border-night-700/50 text-night-400 
                       hover:text-white hover:bg-night-700/60 transition-all duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-8">
          {/* Weather API Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Key className="w-5 h-5 text-ice-400" />
              <h3 className="text-lg font-semibold text-white">Weather API</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-night-400 mb-2">Provider</label>
                <select
                  value={weatherProvider}
                  onChange={(e) => setWeatherProvider(e.target.value)}
                  className="w-full glass-input"
                >
                  <option value="openweathermap">OpenWeatherMap</option>
                  <option value="weatherapi">WeatherAPI</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-night-400 mb-2">
                  API Key {hasApiKey && <span className="text-aurora-400">(configured)</span>}
                </label>
                <input
                  type="password"
                  value={weatherApiKey}
                  onChange={(e) => setWeatherApiKey(e.target.value)}
                  placeholder={hasApiKey ? '••••••••••••••••' : 'Enter API key'}
                  className="w-full glass-input"
                />
                <p className="text-xs text-night-500 mt-2">
                  Leave blank to keep existing key
                </p>
              </div>
            </div>
          </div>

          {/* Location Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-5 h-5 text-ice-400" />
              <h3 className="text-lg font-semibold text-white">Location</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-night-400 mb-2">Latitude</label>
                <input
                  type="text"
                  value={latitude}
                  onChange={(e) => setLatitude(e.target.value)}
                  placeholder={config?.latitude || '45.5017'}
                  className="w-full glass-input"
                />
              </div>
              <div>
                <label className="block text-sm text-night-400 mb-2">Longitude</label>
                <input
                  type="text"
                  value={longitude}
                  onChange={(e) => setLongitude(e.target.value)}
                  placeholder={config?.longitude || '-73.5673'}
                  className="w-full glass-input"
                />
              </div>
            </div>
          </div>

          {/* Bridge Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Wifi className="w-5 h-5 text-ice-400" />
              <h3 className="text-lg font-semibold text-white">Hue Bridge</h3>
            </div>

            <div className="p-4 rounded-xl bg-night-800/40 border border-night-700/50">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">
                    {config?.bridgeIp || 'Not connected'}
                  </div>
                  <div className="text-sm text-night-500">
                    {config?.bridgeIp ? 'Connected' : 'No bridge configured'}
                  </div>
                </div>
                {config?.bridgeIp && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={async () => {
                        try {
                          await api.post('/api/hue/reconnect');
                        } catch (error) {
                          console.error('Failed to reconnect bridge:', error);
                        }
                      }}
                      className="p-2 rounded-lg bg-night-700/60 border border-night-600/70 text-night-100 
                                 hover:bg-night-600/80 transition-all duration-200"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleResetBridge}
                      className="p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 
                                 hover:bg-red-500/20 transition-all duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* About Section */}
          <div className="pt-4 border-t border-night-700/50">
            <div className="text-center">
              <h3 className="font-display text-lg font-semibold text-white mb-1">
                Anaakwad
              </h3>
              <p className="text-sm text-night-500 mb-2">
                Weather-Reactive Lighting for Hue
              </p>
              <p className="text-xs text-night-600">
                Version 1.0.0
              </p>
            </div>
          </div>
        </div>

        {/* Save button */}
        <div className="mt-8 flex gap-4">
          <button
            onClick={onClose}
            className="flex-1 glass-button"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 glass-button-primary flex items-center justify-center gap-2"
          >
            {saving ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : saved ? (
              <>
                <Save className="w-4 h-4" />
                Saved!
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
