import React, { useState, useEffect } from 'react';
import { Sliders, Power, RotateCcw, Sun } from 'lucide-react';
import { useApi } from '../hooks/useApi';

const manualScenes = [
  { name: 'Northern Lights', color: '#22c55e', brightness: 0.7 },
  { name: 'Arctic Blue', color: '#0ea5e9', brightness: 0.8 },
  { name: 'Warm Sunset', color: '#f97316', brightness: 0.75 },
  { name: 'Deep Purple', color: '#9333ea', brightness: 0.6 },
  { name: 'Soft White', color: '#faf5ea', brightness: 0.9 },
  { name: 'Night Mode', color: '#1e293b', brightness: 0.2 }
];

export default function AnimationControls({ selectedLights, weatherMode, currentAnimation }) {
  const [intensity, setIntensity] = useState(100);
  const [brightness, setBrightness] = useState(100);
  const [activeScene, setActiveScene] = useState(null);
  const api = useApi();

  // Fetch initial values
  useEffect(() => {
    async function fetchConfig() {
      try {
        const config = await api.get('/api/config');
        if (config.animationIntensity !== undefined) {
          setIntensity(Math.round(config.animationIntensity * 100));
        }
        if (config.masterBrightness !== undefined) {
          setBrightness(Math.round(config.masterBrightness * 100));
        }
      } catch (error) {
        console.error('Failed to fetch config:', error);
      }
    }
    fetchConfig();
  }, [api]);

  useEffect(() => {
    if (weatherMode) {
      setActiveScene(null);
    }
  }, [weatherMode]);

  const handleIntensityChange = async (value) => {
    setIntensity(value);
    try {
      await api.post('/api/animation/intensity', { intensity: value / 100 });
    } catch (error) {
      console.error('Failed to set intensity:', error);
    }
  };

  const handleBrightnessChange = async (value) => {
    setBrightness(value);
    try {
      await api.post('/api/brightness', { brightness: value / 100 });
    } catch (error) {
      console.error('Failed to set brightness:', error);
    }
  };

  const handleApplyScene = async (scene, index) => {
    if (selectedLights.length === 0) return;
    
    try {
      await api.post('/api/animation/override', { scene });
      setActiveScene(index);
    } catch (error) {
      console.error('Failed to apply scene:', error);
    }
  };

  const handleClearOverride = async () => {
    try {
      await api.post('/api/animation/clear-override');
      setActiveScene(null);
    } catch (error) {
      console.error('Failed to clear override:', error);
    }
  };

  return (
    <div className="glass-panel p-6">
      <div className="flex items-center gap-3 mb-6">
        <Sliders className="w-5 h-5 text-ice-400" />
        <h2 className="section-title">Controls</h2>
      </div>

      {/* Master Brightness Slider */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-yellow-400" />
            <label className="text-sm text-night-400">Master Brightness</label>
          </div>
          <span className="text-sm text-white font-medium">{brightness}%</span>
        </div>
        <input
          type="range"
          min="5"
          max="100"
          value={brightness}
          onChange={(e) => handleBrightnessChange(Number(e.target.value))}
          className="w-full accent-yellow-500"
        />
        <div className="flex justify-between text-[10px] text-night-600 mt-1">
          <span>Dim</span>
          <span>Full</span>
        </div>
      </div>

      {/* Animation intensity */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <label className="text-sm text-night-400">Animation Intensity</label>
          <span className="text-sm text-white font-medium">{intensity}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={intensity}
          onChange={(e) => handleIntensityChange(Number(e.target.value))}
          className="w-full accent-ice-500"
        />
        <div className="flex justify-between text-[10px] text-night-600 mt-1">
          <span>Subtle</span>
          <span>Dynamic</span>
        </div>
      </div>

      {/* Manual scenes */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-night-300">Manual Scenes</h3>
          {activeScene !== null && (
            <button
              onClick={handleClearOverride}
              className="flex items-center gap-1.5 text-xs text-night-400 hover:text-white transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Clear Override
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          {manualScenes.map((scene, index) => (
            <button
              key={index}
              onClick={() => handleApplyScene(scene, index)}
              disabled={selectedLights.length === 0}
              className={`relative p-3 rounded-xl border transition-all duration-200 text-left ${
                activeScene === index
                  ? 'border-ice-500/50 bg-ice-900/20'
                  : 'border-night-700/50 bg-night-800/40 hover:border-night-600/50'
              } ${selectedLights.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center gap-2 mb-1">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: scene.color }}
                />
                <span className="text-sm text-white font-medium">{scene.name}</span>
              </div>
              <div className="text-xs text-night-500">
                {Math.round(scene.brightness * 100)}% brightness
              </div>
              {activeScene === index && (
                <div className="absolute top-2 right-2">
                  <Power className="w-3 h-3 text-ice-400" />
                </div>
              )}
            </button>
          ))}
        </div>

        {selectedLights.length === 0 && (
          <p className="text-xs text-night-500 text-center mt-2">
            Select lights to use manual scenes
          </p>
        )}

        {weatherMode && activeScene !== null && (
          <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
            <p className="text-xs text-yellow-400">
              Manual override active. Weather mode will resume when cleared.
            </p>
          </div>
        )}
      </div>

      {/* Current animation info */}
      {currentAnimation && weatherMode && activeScene === null && (
        <div className="mt-6 pt-6 border-t border-night-700/50">
          <h3 className="text-sm font-medium text-night-300 mb-3">Active Effect</h3>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-white font-medium capitalize">
                {currentAnimation.condition}
              </div>
              <div className="text-sm text-night-500">
                {currentAnimation.animation}
              </div>
            </div>
            <div className="flex gap-1">
              {currentAnimation.palette?.slice(0, 4).map((color, i) => (
                <div
                  key={i}
                  className="w-4 h-4 rounded animate-pulse"
                  style={{ 
                    backgroundColor: color,
                    animationDelay: `${i * 0.2}s`
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
