import React, { useState, useEffect } from 'react';
import { 
  Cloud, ArrowRight, ArrowLeft, Check, AlertCircle, Loader2,
  MapPin, Key, Wifi, Search
} from 'lucide-react';
import { useApi } from '../hooks/useApi';

export default function SetupWizard({ onComplete, config }) {
  const [step, setStep] = useState(1);
  const [bridgeIp, setBridgeIp] = useState(config?.bridgeIp || '');
  const [discoveredBridges, setDiscoveredBridges] = useState([]);
  const [discovering, setDiscovering] = useState(false);
  const [registering, setRegistering] = useState(false);
  const [registerError, setRegisterError] = useState('');
  const [bridgeConnected, setBridgeConnected] = useState(false);
  
  const [weatherApiKey, setWeatherApiKey] = useState(config?.weatherApiKey || "");
  const [weatherProvider, setWeatherProvider] = useState(config?.weatherProvider || "openweathermap");
  const [latitude, setLatitude] = useState(config?.latitude || '');
  const [longitude, setLongitude] = useState(config?.longitude || '');
  const [gettingLocation, setGettingLocation] = useState(false);

  const api = useApi();

  const totalSteps = 3;

  // Auto-discover bridges on mount
  useEffect(() => {
    if (step === 1) {
      discoverBridges();
    }
  }, [step]);

  const discoverBridges = async () => {
    setDiscovering(true);
    try {
      const bridges = await api.get('/api/hue/discover');
      setDiscoveredBridges(bridges);
      if (bridges.length === 1) {
        setBridgeIp(bridges[0].ip);
      }
    } catch (error) {
      console.error('Discovery failed:', error);
    } finally {
      setDiscovering(false);
    }
  };

  const registerBridge = async () => {
    if (!bridgeIp) return;
    
    setRegistering(true);
    setRegisterError('');
    
    try {
      await api.post('/api/hue/register', { bridgeIp });
      setBridgeConnected(true);
      setTimeout(() => setStep(2), 1000);
    } catch (error) {
      if (error.message.includes('LINK_BUTTON')) {
        setRegisterError('Please press the link button on your Hue bridge, then try again.');
      } else {
        setRegisterError(error.message);
      }
    } finally {
      setRegistering(false);
    }
  };

  const getLocation = () => {
    setGettingLocation(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLatitude(position.coords.latitude.toFixed(6));
          setLongitude(position.coords.longitude.toFixed(6));
          setGettingLocation(false);
        },
        (error) => {
          console.error('Location error:', error);
          setGettingLocation(false);
        }
      );
    } else {
      setGettingLocation(false);
    }
  };

  const saveWeatherConfig = async () => {
    try {
      await api.post('/api/keys/weather', { 
        apiKey: weatherApiKey, 
        provider: weatherProvider 
      });
      await api.post('/api/location', { latitude, longitude });
      setStep(3);
    } catch (error) {
      console.error('Failed to save weather config:', error);
    }
  };

  const finishSetup = async () => {
    onComplete();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="aurora-bg" />
      <div className="stars" />
      
      <div className="w-full max-w-lg relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-ice-500/30 to-aurora-500/30 flex items-center justify-center">
            <Cloud className="w-8 h-8 text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold text-white mb-2">
            Welcome to Anaakwad
          </h1>
          <p className="text-night-400">Let's set up your weather-reactive lighting</p>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                s === step
                  ? 'w-8 bg-ice-500'
                  : s < step
                    ? 'bg-aurora-500'
                    : 'bg-night-700'
              }`}
            />
          ))}
        </div>

        {/* Card */}
        <div className="glass-panel p-8">
          {/* Step 1: Bridge Connection */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-ice-500/20 flex items-center justify-center">
                  <Wifi className="w-5 h-5 text-ice-400" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-white">Connect Hue Bridge</h2>
                  <p className="text-sm text-night-400">Step 1 of {totalSteps}</p>
                </div>
              </div>

              {/* Discovered bridges */}
              {discoveredBridges.length > 0 && (
                <div className="space-y-2">
                  <label className="block text-sm text-night-400">Discovered Bridges</label>
                  {discoveredBridges.map((bridge) => (
                    <button
                      key={bridge.id}
                      onClick={() => setBridgeIp(bridge.ip)}
                      className={`w-full p-3 rounded-xl border transition-all duration-200 text-left ${
                        bridgeIp === bridge.ip
                          ? 'border-ice-500/50 bg-ice-900/20'
                          : 'border-night-700/50 bg-night-800/40 hover:border-night-600/50'
                      }`}
                    >
                      <div className="text-white font-medium">{bridge.ip}</div>
                      <div className="text-xs text-night-500">ID: {bridge.id}</div>
                    </button>
                  ))}
                </div>
              )}

              {/* Manual IP input */}
              <div>
                <label className="block text-sm text-night-400 mb-2">Bridge IP Address</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={bridgeIp}
                    onChange={(e) => setBridgeIp(e.target.value)}
                    placeholder="192.168.1.x"
                    className="flex-1 glass-input"
                  />
                  <button
                    onClick={discoverBridges}
                    disabled={discovering}
                    className="glass-button"
                  >
                    {discovering ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {registerError && (
                <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-400">{registerError}</p>
                </div>
              )}

              {bridgeConnected && (
                <div className="p-3 rounded-lg bg-aurora-500/10 border border-aurora-500/20 flex items-center gap-3">
                  <Check className="w-5 h-5 text-aurora-400" />
                  <p className="text-sm text-aurora-400">Bridge connected successfully!</p>
                </div>
              )}

              <button
                onClick={registerBridge}
                disabled={!bridgeIp || registering || bridgeConnected}
                className="w-full glass-button-primary flex items-center justify-center gap-2"
              >
                {registering ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Press bridge button...
                  </>
                ) : bridgeConnected ? (
                  <>
                    <Check className="w-4 h-4" />
                    Connected
                  </>
                ) : (
                  <>
                    Connect Bridge
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 2: Weather API */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-ice-500/20 flex items-center justify-center">
                  <Key className="w-5 h-5 text-ice-400" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-white">Weather API</h2>
                  <p className="text-sm text-night-400">Step 2 of {totalSteps}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm text-night-400 mb-2">Weather Provider</label>
                <select
                  value={weatherProvider}
                  onChange={(e) => setWeatherProvider(e.target.value)}
                  className="w-full glass-input"
                >
                  <option value="openweathermap">OpenWeatherMap (Free)</option>
                  <option value="weatherapi">WeatherAPI</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-night-400 mb-2">API Key</label>
                <input
                  type="text"
                  value={weatherApiKey}
                  onChange={(e) => setWeatherApiKey(e.target.value)}
                  placeholder="Enter your API key"
                  className="w-full glass-input"
                />
                <p className="text-xs text-night-500 mt-2">
                  Get a free key at{' '}
                  <a 
                    href="https://openweathermap.org/api" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-ice-400 hover:underline"
                  >
                    openweathermap.org
                  </a>
                </p>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setStep(1)}
                  className="glass-button flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!weatherApiKey}
                  className="flex-1 glass-button-primary flex items-center justify-center gap-2"
                >
                  Continue
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Location */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-ice-500/20 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-ice-400" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-white">Your Location</h2>
                  <p className="text-sm text-night-400">Step 3 of {totalSteps}</p>
                </div>
              </div>

              <button
                onClick={getLocation}
                disabled={gettingLocation}
                className="w-full glass-button flex items-center justify-center gap-2"
              >
                {gettingLocation ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Getting location...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4" />
                    Use My Location
                  </>
                )}
              </button>

              <div className="text-center text-night-500 text-sm">or enter manually</div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-night-400 mb-2">Latitude</label>
                  <input
                    type="text"
                    value={latitude}
                    onChange={(e) => setLatitude(e.target.value)}
                    placeholder="45.5017"
                    className="w-full glass-input"
                  />
                </div>
                <div>
                  <label className="block text-sm text-night-400 mb-2">Longitude</label>
                  <input
                    type="text"
                    value={longitude}
                    onChange={(e) => setLongitude(e.target.value)}
                    placeholder="-73.5673"
                    className="w-full glass-input"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setStep(2)}
                  className="glass-button flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </button>
                <button
                  onClick={async () => {
                    await saveWeatherConfig();
                    finishSetup();
                  }}
                  disabled={!latitude || !longitude}
                  className="flex-1 glass-button-primary flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Finish Setup
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
