#!/bin/bash

# Anaakwad Local Development Startup Script
# This script starts both backend and frontend servers

echo "
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     ▄▀▄ ▄ █ ▄▀▄ ▄▀▄ █▄▀ █   █ ▄▀▄ █▀▄                       ║
║     █▀█ █ █ █▀█ █▀█ █ █ ▀▄▀▄▀ █▀█ █▄▀                       ║
║                                                              ║
║     Weather-Reactive Lighting for Hue         ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  No .env file found. Copying from .env.example..."
    cp .env.example .env
    echo "📝 Please edit .env with your configuration before continuing."
    exit 1
fi

# Check for node
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed."
    echo "   Please install Node.js 20+ from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js 18+ is required. Current version: $(node -v)"
    exit 1
fi

echo "📦 Installing backend dependencies..."
cd backend
npm install
cd ..

echo "📦 Installing frontend dependencies..."
cd frontend
npm install
cd ..

echo ""
echo "🚀 Starting Anaakwad..."
echo ""

# Start backend in background
cd backend
npm run dev &
BACKEND_PID=$!
cd ..

# Wait a moment for backend to start
sleep 2

# Start frontend
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "✅ Anaakwad is running!"
echo ""
echo "   Frontend: http://localhost:3000"
echo "   Backend:  http://localhost:3001"
echo ""
echo "Press Ctrl+C to stop all services"

# Handle shutdown
cleanup() {
    echo ""
    echo "🛑 Shutting down..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    exit 0
}

trap cleanup SIGINT SIGTERM

# Wait for processes
wait
