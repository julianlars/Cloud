# ☁️ Anaakwad

**Weather-Reactive Lighting for Hue** — Weather-Reactive Philips Hue Automation

Anaakwad (Ojibwe for "Weather-Reactive Lighting for Hue") is a self-hosted automation app that reads real outdoor weather conditions and applies dynamic animated lighting scenes to your Philips Hue lights. Think IFTTT, but specifically designed for creating immersive, weather-synchronized lighting experiences.

![Anaakwad](https://img.shields.io/badge/Version-1.0.0-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Node](https://img.shields.io/badge/Node-20+-brightgreen)

## ✨ Features

### Weather-Reactive Animations
- **Rain** — Deep blue palette with slow breathing pulse and raindrop shimmer effects
- **Thunderstorm** — Purple/blue base with random lightning flash sequences and brightness rumble
- **Snow** — Ice blue to white gradient with slow drifting fade and blowing snow shimmer
- **Cloudy** — Gray-blue desaturated tones with gentle cloud drift animation
- **Hot/Heatwave** — Red/orange/amber palette with heat ripple oscillation
- **Windy** — Teal/cyan colors with sequential wave animation across bulbs
- **Fog** — Dim cool white with ultra-slow mist breathing
- **Clear Day** — Stable daylight white
- **Sunrise** — Smooth 3-4 minute gradient ramp from deep red to warm white
- **Sunset** — Randomized orange/amber candle-like flicker (Easter egg event!)

### Core Functionality
- 🌡️ Real-time weather polling (60-second intervals)
- 💡 Philips Hue local bridge integration with auto-discovery
- 🎨 Customizable color palettes per weather condition
- ⚡ Smooth animation engine with multiple easing curves
- 🔄 Manual scene override with automatic weather mode resume
- 📱 Modern, responsive dark UI with northern sky aesthetic
- 🔌 WebSocket real-time status updates
- 🐳 Docker deployment ready

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ (for local development)
- Docker & Docker Compose (for containerized deployment)
- Philips Hue Bridge on your local network
- Weather API key (free from OpenWeatherMap)

### Option 1: Docker (Recommended)

```bash
# Clone or download the project
cd anaakwad

# Copy environment file and configure
cp .env.example .env
# Edit .env with your weather API key and location

# Build and start
docker-compose up -d

# Access the UI
open http://localhost:3000
```

### Option 2: Local Development

```bash
# Backend
cd backend
npm install
cp ../.env.example .env
# Edit .env with your configuration
npm run dev

# Frontend (new terminal)
cd frontend
npm install
npm run dev

# Access the UI
open http://localhost:3000
```

## ⚙️ Configuration

### Weather API Setup

1. Sign up at [OpenWeatherMap](https://openweathermap.org/api) (free tier available)
2. Generate an API key
3. Add to your `.env` file or configure via the UI

### Hue Bridge Connection

1. Ensure your Hue Bridge is on the same network
2. The app will auto-discover bridges
3. Press the link button on your bridge when prompted
4. Select which lights/rooms to control

### Location

Enter your coordinates for accurate weather data:
- Use the "Get My Location" button in setup
- Or manually enter latitude/longitude
- Find coordinates at [latlong.net](https://www.latlong.net/)

## 🎨 Customization

### Weather Mappings

Each weather condition can be customized:
- **Color Palette** — Up to 6 colors that cycle during animations
- **Animation Type** — Choose from 10+ animation styles
- **Intensity** — Control how pronounced the effects are (0-100%)

### Manual Scenes

Quick-access manual overrides:
- Northern Lights
- Arctic Blue
- Warm Sunset
- Deep Purple
- Soft White
- Night Mode

Manual overrides take priority until cleared or weather mode is restarted.

## 🔧 Animation Engine

The animation engine supports various effects:

| Animation | Description | Cycle Time |
|-----------|-------------|------------|
| `rainPulse` | Slow breathing with random shimmer | 15-20s |
| `lightningFlash` | Random bright flashes with rumble | Variable |
| `snowDrift` | Slow color drift with subtle shimmer | 30-45s |
| `cloudDrift` | Gentle fades with desaturation waves | 25s |
| `heatRipple` | 2-5% brightness oscillation | 3s |
| `windSway` | Sequential wave across bulbs | 4s |
| `mistFade` | Ultra-slow low-contrast breathing | 45s |
| `sunriseRamp` | Smooth gradient progression | 3-4min |
| `candleFlicker` | Natural flicker simulation | Continuous |

### Easing Functions
- Cosine ease (natural breathing)
- Smoothstep (gradual transitions)
- Linear (constant rate)

## 📁 Project Structure

```
anaakwad/
├── backend/
│   ├── src/
│   │   ├── api/          # REST API routes
│   │   ├── services/     # Hue, Weather, Config services
│   │   ├── animations/   # Animation engine
│   │   └── index.js      # Server entry point
│   ├── Dockerfile
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── hooks/        # Custom hooks
│   │   ├── styles/       # CSS & Tailwind
│   │   └── App.jsx       # Main app
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
├── .env.example
└── README.md
```

## 🌐 API Reference

### Weather Mode
```
GET  /api/weather-mode          # Get current mode status
POST /api/weather-mode          # Toggle weather mode { enabled: boolean }
```

### Weather
```
GET  /api/weather               # Current weather data
POST /api/weather/refresh       # Force weather refresh
GET  /api/weather/mappings      # Get all weather→animation mappings
PUT  /api/weather/mappings/:id  # Update a mapping
```

### Hue
```
GET  /api/hue/status            # Bridge connection status
GET  /api/hue/discover          # Discover bridges on network
POST /api/hue/register          # Register with bridge { bridgeIp }
GET  /api/hue/lights            # List all lights
GET  /api/hue/groups            # List all rooms/groups
POST /api/hue/lights/select     # Select lights { lights: [] }
```

### Animation
```
GET  /api/animation/status      # Current animation state
POST /api/animation/preview     # Preview a condition { condition }
POST /api/animation/override    # Apply manual scene { scene }
POST /api/animation/intensity   # Set intensity { intensity: 0-1 }
```

### WebSocket

Connect to `ws://localhost:3001` for real-time updates:

```javascript
// Message types received:
{ type: 'state', data: { ... } }           // Full state on connect
{ type: 'weather', data: { ... } }         // Weather updates
{ type: 'animation', data: { ... } }       // Animation changes
{ type: 'animationState', data: { ... } }  // Animation state changes
{ type: 'weatherMode', data: { enabled } } // Mode toggle
{ type: 'selectedLights', data: { ... } }  // Light selection changes
```

## 🛡️ Network Requirements

- Backend needs access to:
  - Local network (for Hue Bridge discovery/control)
  - Internet (for weather API)
- Default ports:
  - `3000` — Frontend UI
  - `3001` — Backend API & WebSocket

## 🔮 Future Ideas

- [ ] AI-generated moods based on weather severity
- [ ] Custom Ojibwe-inspired seasonal themes
- [ ] Lightning severity scaling based on storm intensity
- [ ] Hue gradient/lightstrip support
- [ ] Home Assistant webhook integration
- [ ] Multi-home bridge support
- [ ] Weather forecast preview mode

## 📜 License

MIT License — feel free to use, modify, and share!

## 🙏 Credits

- Weather data: [OpenWeatherMap](https://openweathermap.org/)
- Lighting: [Philips Hue](https://www.philips-hue.com/)
- Name inspiration: Ojibwe language (ᐊᓈᑾᑦ — Anaakwad — "cloud")

---

**Anaakwad** — *Let the weather paint your world* ☁️🌈💡
