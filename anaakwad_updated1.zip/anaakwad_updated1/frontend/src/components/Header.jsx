import React from 'react';
import { Settings, Cloud, Wifi, WifiOff } from 'lucide-react';

export default function Header({ 
  weatherMode, 
  onToggleWeatherMode, 
  onOpenSettings,
  bridgeConnected,
  wsConnected
}) {
  return (
    <header className="glass-panel p-6">
      <div className="flex items-center justify-between">
        {/* Logo & Title */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-ice-500/30 to-aurora-500/30 flex items-center justify-center">
              <Cloud className="w-6 h-6 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-night-900 flex items-center justify-center">
              <div className={`status-indicator ${bridgeConnected ? 'status-indicator-active' : 'status-indicator-inactive'}`} />
            </div>
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-white tracking-tight">
              Anaakwad
            </h1>
            <p className="text-sm text-night-400">Weather-Reactive Lighting for Hue</p>
          </div>
        </div>

        {/* Status & Controls */}
        <div className="flex items-center gap-6">
          {/* Connection status */}
          <div className="hidden sm:flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              {wsConnected ? (
                <Wifi className="w-4 h-4 text-aurora-400" />
              ) : (
                <WifiOff className="w-4 h-4 text-night-500" />
              )}
              <span className={wsConnected ? 'text-night-300' : 'text-night-500'}>
                {wsConnected ? 'Live' : 'Offline'}
              </span>
            </div>
            <div className="w-px h-4 bg-night-700" />
            <div className="flex items-center gap-2">
              <div className={`status-indicator ${bridgeConnected ? 'status-indicator-active' : 'status-indicator-inactive'}`} />
              <span className={bridgeConnected ? 'text-night-300' : 'text-night-500'}>
                {bridgeConnected ? 'Bridge Connected' : 'No Bridge'}
              </span>
            </div>
          </div>

          {/* Weather Mode Toggle */}
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-night-300 hidden sm:inline">
              Weather Mode
            </span>
            <button
              onClick={onToggleWeatherMode}
              className={`toggle-track ${weatherMode ? 'toggle-track-active' : ''}`}
              aria-label="Toggle weather mode"
            >
              <div className={`toggle-thumb ${weatherMode ? 'toggle-thumb-active' : ''}`} />
            </button>
          </div>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            className="p-2.5 rounded-xl bg-night-800/60 border border-night-700/50 text-night-400 
                       hover:text-white hover:bg-night-700/60 transition-all duration-200"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
