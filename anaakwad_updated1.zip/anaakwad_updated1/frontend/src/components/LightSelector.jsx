import React, { useState, useEffect, useRef } from 'react';
import { Lightbulb, Home, Check, RefreshCw } from 'lucide-react';

export default function LightSelector({ lights, groups, selectedLights, onSelectLights }) {
  const [viewMode, setViewMode] = useState('lights'); // 'lights' or 'rooms'
  
  // Visual persistence buffer - cache last known good data
  const [cachedLights, setCachedLights] = useState([]);
  const [cachedGroups, setCachedGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const initialLoadRef = useRef(true);

  // Update cache when we receive valid data
  useEffect(() => {
    if (lights && lights.length > 0) {
      setCachedLights(lights);
      initialLoadRef.current = false;
    }
  }, [lights]);

  useEffect(() => {
    if (groups && groups.length > 0) {
      setCachedGroups(groups);
    }
  }, [groups]);

  // Use cached data if current data is unavailable
  const displayLights = lights && lights.length > 0 ? lights : cachedLights;
  const displayGroups = groups && groups.length > 0 ? groups : cachedGroups;

  // Show loading state only on initial load
  const showLoadingPlaceholder = initialLoadRef.current && displayLights.length === 0;
  const isUsingCachedData = (!lights || lights.length === 0) && cachedLights.length > 0;

  const toggleLight = (lightId) => {
    const newSelection = selectedLights.includes(lightId)
      ? selectedLights.filter(id => id !== lightId)
      : [...selectedLights, lightId];
    onSelectLights(newSelection);
  };

  const toggleRoom = (group) => {
    const roomLightIds = group.lights;
    const allSelected = roomLightIds.every(id => selectedLights.includes(id));
    
    if (allSelected) {
      onSelectLights(selectedLights.filter(id => !roomLightIds.includes(id)));
    } else {
      const newSelection = [...new Set([...selectedLights, ...roomLightIds])];
      onSelectLights(newSelection);
    }
  };

  const selectAll = () => {
    onSelectLights(displayLights.map(l => l.id));
  };

  const selectNone = () => {
    onSelectLights([]);
  };

  return (
    <div className="glass-panel p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title">Lights</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={selectAll}
            className="text-xs text-night-400 hover:text-white transition-colors"
          >
            All
          </button>
          <span className="text-night-600">/</span>
          <button
            onClick={selectNone}
            className="text-xs text-night-400 hover:text-white transition-colors"
          >
            None
          </button>
        </div>
      </div>

      {/* View mode tabs */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setViewMode('lights')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all duration-200 ${
            viewMode === 'lights'
              ? 'bg-night-700/60 text-white'
              : 'text-night-400 hover:text-white'
          }`}
        >
          <Lightbulb className="w-4 h-4" />
          Lights
        </button>
        <button
          onClick={() => setViewMode('rooms')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all duration-200 ${
            viewMode === 'rooms'
              ? 'bg-night-700/60 text-white'
              : 'text-night-400 hover:text-white'
          }`}
        >
          <Home className="w-4 h-4" />
          Rooms
        </button>
      </div>

      {/* Selection count */}
      <div className="text-sm text-night-400 mb-4">
        {selectedLights.length} of {displayLights.length} lights selected
      </div>

      {/* Light/Room list */}
      <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
        {showLoadingPlaceholder ? (
          // Loading skeleton
          <div className="space-y-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-full light-bulb-card flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-night-700/50" />
                  <div>
                    <div className="h-4 w-24 bg-night-700/50 rounded mb-1" />
                    <div className="h-3 w-16 bg-night-800/50 rounded" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : viewMode === 'lights' ? (
          displayLights.length > 0 ? (
            displayLights.map(light => (
              <button
                key={light.id}
                onClick={() => toggleLight(light.id)}
                className={`w-full light-bulb-card flex items-center justify-between transition-all duration-200 ${
                  selectedLights.includes(light.id) ? 'light-bulb-card-selected' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    selectedLights.includes(light.id)
                      ? 'bg-ice-500/20'
                      : 'bg-night-700/50'
                  }`}>
                    <Lightbulb className={`w-4 h-4 transition-colors ${
                      selectedLights.includes(light.id)
                        ? 'text-ice-400'
                        : 'text-night-500'
                    }`} />
                  </div>
                  <div className="text-left">
                    <div className="text-white text-sm font-medium">{light.name}</div>
                    <div className="text-night-500 text-xs">{light.type}</div>
                  </div>
                </div>
                {selectedLights.includes(light.id) && (
                  <Check className="w-4 h-4 text-ice-400" />
                )}
              </button>
            ))
          ) : (
            <div className="text-center py-8 text-night-500">
              <Lightbulb className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No lights found</p>
              <p className="text-xs mt-1">Connect to a Hue bridge first</p>
            </div>
          )
        ) : (
          displayGroups.length > 0 ? (
            displayGroups.filter(g => g.type === 'Room').map(group => {
              const roomLightIds = group.lights;
              const selectedCount = roomLightIds.filter(id => selectedLights.includes(id)).length;
              const allSelected = selectedCount === roomLightIds.length && roomLightIds.length > 0;
              const someSelected = selectedCount > 0 && selectedCount < roomLightIds.length;

              return (
                <button
                  key={group.id}
                  onClick={() => toggleRoom(group)}
                  className={`w-full light-bulb-card flex items-center justify-between transition-all duration-200 ${
                    allSelected ? 'light-bulb-card-selected' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                      allSelected
                        ? 'bg-ice-500/20'
                        : someSelected
                          ? 'bg-ice-500/10'
                          : 'bg-night-700/50'
                    }`}>
                      <Home className={`w-4 h-4 transition-colors ${
                        allSelected
                          ? 'text-ice-400'
                          : someSelected
                            ? 'text-ice-500/70'
                            : 'text-night-500'
                      }`} />
                    </div>
                    <div className="text-left">
                      <div className="text-white text-sm font-medium">{group.name}</div>
                      <div className="text-night-500 text-xs">{roomLightIds.length} lights</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {someSelected && (
                      <span className="text-xs text-night-400">{selectedCount}/{roomLightIds.length}</span>
                    )}
                    {allSelected && (
                      <Check className="w-4 h-4 text-ice-400" />
                    )}
                  </div>
                </button>
              );
            })
          ) : (
            <div className="text-center py-8 text-night-500">
              <Home className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No rooms found</p>
            </div>
          )
        )}
      </div>
    </div>
  );
}
