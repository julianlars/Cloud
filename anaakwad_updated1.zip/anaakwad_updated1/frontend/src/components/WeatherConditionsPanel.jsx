import React, { useState, useEffect } from 'react';
import { 
  Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, Sun, 
  Wind, Thermometer, Sunrise, Sunset, Grid3X3, ArrowRight
} from 'lucide-react';
import { useApi } from '../hooks/useApi';

const weatherIcons = {
  rain: CloudRain,
  thunderstorm: CloudLightning,
  snow: CloudSnow,
  cloudy: Cloud,
  hot: Thermometer,
  windy: Wind,
  fog: CloudFog,
  clear: Sun,
  sunrise: Sunrise,
  sunset: Sunset
};

const weatherDescriptions = {
  rain: 'Precipitation detected',
  thunderstorm: 'Storm activity',
  snow: 'Snowfall conditions',
  cloudy: 'Overcast skies',
  hot: 'High temperature',
  windy: 'Strong wind speeds',
  fog: 'Low visibility',
  clear: 'Clear skies',
  sunrise: 'Dawn period',
  sunset: 'Dusk period'
};

export default function WeatherConditionsPanel({ currentWeather, currentAnimation }) {
  const [mappings, setMappings] = useState({});
  const api = useApi();

  useEffect(() => {
    async function fetchMappings() {
      try {
        const data = await api.get('/api/weather/mappings');
        setMappings(data || {});
      } catch (error) {
        console.error('Failed to fetch mappings:', error);
      }
    }
    fetchMappings();
  }, [api]);

  const allConditions = Object.keys(mappings);
  const applicableConditions = currentWeather?.applicableConditions || [];
  const activeCondition = currentAnimation?.condition;

  if (allConditions.length === 0) {
    return null;
  }

  return (
    <div className="glass-panel p-6">
      <div className="flex items-center gap-3 mb-4">
        <Grid3X3 className="w-5 h-5 text-aurora-400" />
        <div>
          <h2 className="section-title">Weather Conditions</h2>
          <p className="text-xs text-night-500 mt-0.5">
            All conditions the app may transition to based on current weather
          </p>
        </div>
      </div>

      {/* Applicable conditions (can transition to these) */}
      {applicableConditions.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <ArrowRight className="w-3 h-3 text-aurora-400" />
            <span className="text-xs font-medium text-aurora-300 uppercase tracking-wide">
              Active Transitions ({applicableConditions.length})
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {applicableConditions.map(condition => {
              const Icon = weatherIcons[condition] || Cloud;
              const mapping = mappings[condition];
              const isActive = activeCondition === condition;
              
              return (
                <div
                  key={condition}
                  className={`relative p-3 rounded-xl border transition-all duration-300 ${
                    isActive
                      ? 'border-aurora-400 bg-aurora-500/15 shadow-lg shadow-aurora-500/10'
                      : 'border-night-700/60 bg-night-800/40 hover:border-night-600'
                  }`}
                >
                  {isActive && (
                    <div className="absolute top-2 right-2">
                      <div className="w-2 h-2 rounded-full bg-aurora-400 animate-pulse" />
                    </div>
                  )}
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-aurora-300' : 'text-night-400'}`} />
                    <span className={`text-sm font-medium capitalize ${isActive ? 'text-white' : 'text-night-200'}`}>
                      {mapping?.name || condition}
                    </span>
                  </div>
                  <div className="text-[10px] text-night-500 mb-2">
                    {weatherDescriptions[condition] || 'Weather condition'}
                  </div>
                  {/* Color preview */}
                  {mapping?.palette && (
                    <div className="flex gap-0.5">
                      {mapping.palette.slice(0, 4).map((color, i) => (
                        <div
                          key={i}
                          className="flex-1 h-1.5 rounded-full"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* All available conditions */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-medium text-night-400 uppercase tracking-wide">
            All Conditions ({allConditions.length})
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {allConditions.map(condition => {
            const Icon = weatherIcons[condition] || Cloud;
            const mapping = mappings[condition];
            const isApplicable = applicableConditions.includes(condition);
            const isActive = activeCondition === condition;
            
            return (
              <div
                key={condition}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-full border text-xs transition-all ${
                  isActive
                    ? 'border-aurora-400 bg-aurora-500/20 text-aurora-100'
                    : isApplicable
                      ? 'border-ice-500/40 bg-ice-500/10 text-ice-200'
                      : 'border-night-700/50 bg-night-900/40 text-night-400'
                }`}
                title={`${mapping?.name || condition}: ${weatherDescriptions[condition] || ''}`}
              >
                <Icon className="w-3 h-3" />
                <span className="capitalize">{mapping?.name || condition}</span>
                {isActive && (
                  <span className="text-[9px] uppercase tracking-wide text-aurora-300 ml-1">
                    Now
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-4 pt-3 border-t border-night-800/50">
        <div className="flex flex-wrap gap-4 text-[10px] text-night-500">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-aurora-400" />
            <span>Currently Active</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-ice-500/60" />
            <span>Can Transition To</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-night-600" />
            <span>Not Applicable Now</span>
          </div>
        </div>
      </div>
    </div>
  );
}
