import React, { useState, useEffect, useRef } from 'react';
import { 
  Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, Sun, 
  Wind, Thermometer, Sunrise, Sunset, Play, Palette, ChevronDown, ChevronUp, Save, Check
} from 'lucide-react';
import { useApi } from '../hooks/useApi';

const weatherIcons = {
  rain: CloudRain,
  thunderstorm: CloudLightning,
  snow: CloudSnow,
  cloudy: Cloud,
  hot: Thermometer,
  windy: Wind,
  fog: CloudFog,
  clear: Sun,
  sunrise: Sunrise,
  sunset: Sunset
};

const animationOptions = [
  { value: 'rainPulse', label: 'Rain Pulse' },
  { value: 'lightningFlash', label: 'Lightning Flash' },
  { value: 'snowDrift', label: 'Snow Drift' },
  { value: 'cloudDrift', label: 'Cloud Drift' },
  { value: 'heatRipple', label: 'Heat Ripple' },
  { value: 'windSway', label: 'Wind Sway' },
  { value: 'mistFade', label: 'Mist Fade' },
  { value: 'sunriseRamp', label: 'Sunrise Ramp' },
  { value: 'candleFlicker', label: 'Candle Flicker' },
  { value: 'none', label: 'Static (No Animation)' }
];

export default function WeatherMappings({ selectedLights }) {
  const [mappings, setMappings] = useState({});
  const [cycleMode, setCycleMode] = useState('static');
  const [customDurationSeconds, setCustomDurationSeconds] = useState(60);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [expandedCondition, setExpandedCondition] = useState(null);
  const [previewingCondition, setPreviewingCondition] = useState(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [initialMappings, setInitialMappings] = useState({});
  const [initialCycleMode, setInitialCycleMode] = useState('static');
  const [initialCustomDuration, setInitialCustomDuration] = useState(60);
  const api = useApi();
  const hasLoadedRef = useRef(false);

  // Fetch only once on mount
  useEffect(() => {
    if (hasLoadedRef.current) return;
    hasLoadedRef.current = true;
    
    async function fetchMappingsAndConfig() {
      try {
        const [mappingData, configData] = await Promise.all([
          api.get('/api/weather/mappings'),
          api.get('/api/weather/config').catch(() => null)
        ]);
        const loadedMappings = mappingData || {};
        setMappings(loadedMappings);
        setInitialMappings(JSON.parse(JSON.stringify(loadedMappings)));
        
        if (configData) {
          setCycleMode(configData.cycleMode || 'static');
          setInitialCycleMode(configData.cycleMode || 'static');
          if (typeof configData.customDurationMs === 'number') {
            const seconds = Math.max(1, Math.round(configData.customDurationMs / 1000));
            setCustomDurationSeconds(seconds);
            setInitialCustomDuration(seconds);
          }
        }
      } catch (error) {
        console.error('Failed to fetch mappings/config:', error);
      }
    }
    fetchMappingsAndConfig();
  }, [api]);

  // Track unsaved changes
  useEffect(() => {
    const mappingsChanged = JSON.stringify(mappings) !== JSON.stringify(initialMappings);
    const cycleModeChanged = cycleMode !== initialCycleMode;
    const durationChanged = customDurationSeconds !== initialCustomDuration;
    setHasUnsavedChanges(mappingsChanged || cycleModeChanged || durationChanged);
  }, [mappings, cycleMode, customDurationSeconds, initialMappings, initialCycleMode, initialCustomDuration]);

  const handlePreview = async (condition) => {
    if (selectedLights.length === 0) return;
    
    try {
      setPreviewingCondition(condition);
      await api.post('/api/animation/preview', { condition });
      
      setTimeout(() => {
        setPreviewingCondition(null);
      }, 5000);
    } catch (error) {
      console.error('Failed to preview:', error);
      setPreviewingCondition(null);
    }
  };

  const handleUpdateMapping = (condition, updates) => {
    setMappings(prev => {
      const existingMapping = prev[condition] || {};
      return {
        ...prev,
        [condition]: { ...existingMapping, ...updates }
      };
    });
  };

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      const payload = {
        mappings,
        cycleMode
      };
      if (cycleMode === 'custom') {
        const ms = Math.max(1000, Math.round((customDurationSeconds || 60) * 1000));
        payload.customDurationMs = ms;
      }
      await api.put('/api/weather/config', payload);
      
      // Update initial values to current
      setInitialMappings(JSON.parse(JSON.stringify(mappings)));
      setInitialCycleMode(cycleMode);
      setInitialCustomDuration(customDurationSeconds);
      setHasUnsavedChanges(false);
      
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error('Failed to save weather config:', error);
    } finally {
      setSaving(false);
    }
  };

  const conditions = Object.keys(mappings);

  return (
    <div className="glass-panel p-6">
      {/* Header with cycle speed selector and save button */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title">Weather Mappings</h2>
          <div className="flex items-center gap-2 mt-1">
            <Palette className="w-4 h-4 text-night-400" />
            <span className="text-xs text-night-500">Color + Animation per condition</span>
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-2">
          {/* Cycle Speed Selector */}
          <div className="flex flex-wrap gap-1 justify-end">
            {[
              { value: 'static', label: 'Static' },
              { value: '10s', label: '10s' },
              { value: '45s', label: '45s' },
              { value: '2m', label: '2m' },
              { value: '5m', label: '5m' },
              { value: 'custom', label: 'Custom' }
            ].map(option => (
              <button
                key={option.value}
                type="button"
                onClick={() => setCycleMode(option.value)}
                className={`px-2.5 py-1 rounded-full text-[11px] border transition-all duration-200 ${ 
                  cycleMode === option.value
                    ? 'border-aurora-400 bg-aurora-500/10 text-aurora-100'
                    : 'border-night-700 bg-night-900/60 text-night-300 hover:border-night-500'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
          
          {/* Custom duration input */}
          {cycleMode === 'custom' && (
            <div className="flex items-center gap-2 mt-1">
              <input
                type="number"
                min="1"
                value={customDurationSeconds}
                onChange={(e) => setCustomDurationSeconds(Number(e.target.value) || 60)}
                className="w-20 glass-input text-right text-xs py-1"
              />
              <span className="text-[11px] text-night-400">seconds per condition</span>
            </div>
          )}
          
          {/* Save Configuration Button */}
          <button
            type="button"
            onClick={handleSaveAll}
            disabled={saving || !hasUnsavedChanges}
            className={`mt-1 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-all duration-200 ${
              hasUnsavedChanges 
                ? 'glass-button-primary animate-pulse-subtle'
                : saved
                  ? 'bg-green-500/20 border border-green-500/40 text-green-300'
                  : 'glass-button opacity-60'
            }`}
          >
            {saving ? (
              <>
                <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Saving…
              </>
            ) : saved ? (
              <>
                <Check className="w-3 h-3" />
                Saved!
              </>
            ) : (
              <>
                <Save className="w-3 h-3" />
                {hasUnsavedChanges ? 'Save Config' : 'No Changes'}
              </>
            )}
          </button>
        </div>
      </div>

      {/* Condition cards */}
      <div className="space-y-2">
        {conditions.map(condition => {
          const mapping = mappings[condition];
          const Icon = weatherIcons[condition] || Cloud;
          const isExpanded = expandedCondition === condition;
          const isPreviewing = previewingCondition === condition;

          return (
            <div key={condition} className="weather-condition-card">
              <button
                onClick={() => setExpandedCondition(isExpanded ? null : condition)}
                className="w-full flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-night-700/50 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-night-300" />
                  </div>
                  <div className="text-left">
                    <div className="text-white font-medium">{mapping.name}</div>
                    <div className="text-night-500 text-sm">
                      {animationOptions.find(a => a.value === mapping.animation)?.label || mapping.animation}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {/* Color swatches */}
                  <div className="flex gap-1">
                    {mapping.palette?.slice(0, 4).map((color, i) => (
                      <div
                        key={i}
                        className="w-5 h-5 rounded"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-night-500" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-night-500" />
                  )}
                </div>
              </button>

              {/* Expanded edit section */}
              {isExpanded && (
                <div className="mt-4 pt-4 border-t border-night-700/50 space-y-4">
                  {/* Animation selector */}
                  <div>
                    <label className="block text-sm text-night-400 mb-2">Animation</label>
                    <select
                      value={mapping.animation}
                      onChange={(e) => handleUpdateMapping(condition, { animation: e.target.value })}
                      className="w-full glass-input"
                    >
                      {animationOptions.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Color palette */}
                  <div>
                    <label className="block text-sm text-night-400 mb-2">Color Palette</label>
                    <div className="flex flex-wrap gap-2">
                      {mapping.palette?.map((color, i) => (
                        <div key={i} className="relative group">
                          <input
                            type="color"
                            value={color}
                            onChange={(e) => {
                              const newPalette = [...mapping.palette];
                              newPalette[i] = e.target.value;
                              handleUpdateMapping(condition, { palette: newPalette });
                            }}
                            className="w-10 h-10 rounded-lg cursor-pointer border-2 border-night-600/50
                                       hover:border-white/50 transition-all"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Intensity slider */}
                  <div>
                    <label className="block text-sm text-night-400 mb-2">
                      Intensity: {Math.round((mapping.intensity || 1) * 100)}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={(mapping.intensity || 1) * 100}
                      onChange={(e) => handleUpdateMapping(condition, { intensity: e.target.value / 100 })}
                      className="w-full accent-ice-500"
                    />
                  </div>

                  {/* Preview button */}
                  <button
                    onClick={() => handlePreview(condition)}
                    disabled={selectedLights.length === 0 || isPreviewing}
                    className={`w-full glass-button flex items-center justify-center gap-2 ${
                      selectedLights.length === 0 ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    <Play className={`w-4 h-4 ${isPreviewing ? 'animate-pulse' : ''}`} />
                    {isPreviewing ? 'Previewing...' : 'Preview'}
                  </button>
                  {selectedLights.length === 0 && (
                    <p className="text-xs text-night-500 text-center">Select lights to preview</p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
