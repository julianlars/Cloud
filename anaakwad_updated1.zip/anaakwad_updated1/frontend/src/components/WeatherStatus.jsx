import React, { useState, useEffect, useRef } from 'react';
import { 
  Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, Sun, 
  Wind, Thermometer, Sunrise, Sunset, RefreshCw, Droplets
} from 'lucide-react';

const weatherIcons = {
  rain: CloudRain,
  thunderstorm: CloudLightning,
  snow: CloudSnow,
  cloudy: Cloud,
  hot: Thermometer,
  windy: Wind,
  fog: CloudFog,
  clear: Sun,
  sunrise: Sunrise,
  sunset: Sunset
};

const weatherColors = {
  rain: 'from-blue-500/30 to-blue-700/30',
  thunderstorm: 'from-purple-500/30 to-purple-800/30',
  snow: 'from-cyan-300/30 to-white/20',
  cloudy: 'from-gray-500/30 to-gray-700/30',
  hot: 'from-orange-500/30 to-red-600/30',
  windy: 'from-teal-400/30 to-cyan-500/30',
  fog: 'from-gray-400/30 to-gray-500/20',
  clear: 'from-yellow-400/30 to-orange-400/30',
  sunrise: 'from-orange-400/30 to-yellow-300/30',
  sunset: 'from-orange-500/30 to-red-500/30'
};

const animationLabels = {
  rainPulse: 'Rain Pulse',
  lightningFlash: 'Lightning Flash',
  snowDrift: 'Snow Drift',
  cloudDrift: 'Cloud Drift',
  heatRipple: 'Heat Ripple',
  windSway: 'Wind Sway',
  mistFade: 'Mist Fade',
  sunriseRamp: 'Sunrise Ramp',
  candleFlicker: 'Candle Flicker',
  none: 'Static'
};

export default function WeatherStatus({ weather, animation, weatherMode, onRefresh }) {
  // Visual persistence buffer - cache last known good data
  const [cachedWeather, setCachedWeather] = useState(null);
  const [cachedAnimation, setCachedAnimation] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const lastUpdateRef = useRef(Date.now());

  // Update cache when we receive valid data
  useEffect(() => {
    if (weather && Object.keys(weather).length > 0 && weather.condition) {
      setCachedWeather(weather);
      lastUpdateRef.current = Date.now();
    }
  }, [weather]);

  useEffect(() => {
    if (animation && Object.keys(animation).length > 0) {
      setCachedAnimation(animation);
    }
  }, [animation]);

  // Use cached data if current data is unavailable
  const displayWeather = weather?.condition ? weather : cachedWeather;
  const displayAnimation = animation?.animation ? animation : cachedAnimation;

  const condition = displayWeather?.condition || 'clear';
  const Icon = weatherIcons[condition] || Sun;
  const gradientClass = weatherColors[condition] || weatherColors.clear;

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      // Minimum spinner time for visual feedback
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  // Calculate time since last update
  const timeSinceUpdate = Date.now() - lastUpdateRef.current;
  const isStale = timeSinceUpdate > 5 * 60 * 1000; // 5 minutes

  return (
    <div className="glass-panel p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="section-title">Current Conditions</h2>
          {isStale && cachedWeather && (
            <p className="text-xs text-yellow-500/80 mt-1">
              Data may be outdated • Click refresh to update
            </p>
          )}
        </div>
        <button
          onClick={handleRefresh}
          disabled={isRefreshing}
          className={`p-2 rounded-lg bg-night-800/60 border border-night-700/50 text-night-400 
                     hover:text-white hover:bg-night-700/60 transition-all duration-200 ${
                       isRefreshing ? 'opacity-50' : ''
                     }`}
          aria-label="Refresh weather"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {displayWeather ? (
        <div className={`transition-opacity duration-300 ${!weather?.condition && cachedWeather ? 'opacity-75' : 'opacity-100'}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Weather display */}
            <div className="flex items-center gap-6">
              <div className="weather-icon-container">
                <div className={`weather-icon-glow bg-gradient-to-br ${gradientClass}`} />
                <Icon className="w-12 h-12 text-white relative z-10" />
              </div>
              <div>
                <div className="text-3xl font-display font-bold text-white">
                  {displayWeather.temperature != null 
                    ? `${((displayWeather.temperature * 9/5) + 32).toFixed(1)}°F`
                    : '--°F'
                  }
                </div>
                <div className="text-night-400 capitalize">
                  {displayWeather.raw?.description || condition}
                </div>
                {displayWeather.location && (
                  <div className="text-sm text-night-500 mt-1">{displayWeather.location}</div>
                )}
              </div>
            </div>

            {/* Details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Droplets className="w-5 h-5 text-ice-400" />
                <div>
                  <div className="text-sm text-night-400">Humidity</div>
                  <div className="text-white font-medium">{displayWeather.humidity ?? '--'}%</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Wind className="w-5 h-5 text-teal-400" />
                <div>
                  <div className="text-sm text-night-400">Wind</div>
                  <div className="text-white font-medium">{displayWeather.windSpeed?.toFixed(1) ?? '--'} m/s</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Cloud className="w-5 h-5 text-night-400" />
                <div>
                  <div className="text-sm text-night-400">Clouds</div>
                  <div className="text-white font-medium">{displayWeather.cloudiness ?? '--'}%</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Sun className="w-5 h-5 text-yellow-400" />
                <div>
                  <div className="text-sm text-night-400">Visibility</div>
                  <div className="text-white font-medium">
                    {displayWeather.visibility ? (displayWeather.visibility / 1000).toFixed(1) : '--'} km
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Applicable conditions for lights */}
          {displayWeather?.applicableConditions && displayWeather.applicableConditions.length > 0 && (
            <div className="mt-6 pt-4 border-t border-night-800/60">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-night-200">Applicable Conditions</h3>
                  <p className="text-xs text-night-500">
                    All weather modes your lights may represent right now.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {displayWeather.applicableConditions.map((cond) => {
                  const CondIcon = weatherIcons[cond] || Cloud;
                  const isActive = displayAnimation?.condition === cond;
                  return (
                    <div
                      key={cond}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs transition-all duration-200 ${isActive
                          ? 'border-aurora-400 bg-aurora-500/10 text-aurora-100'
                          : 'border-night-700 bg-night-900/40 text-night-300'
                      }`}
                    >
                      <CondIcon className="w-3 h-3" />
                      <span className="capitalize">{cond}</span>
                      {isActive && (
                        <span className="text-[10px] uppercase tracking-wide text-aurora-300">
                          Active
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Active animation status */}
          {weatherMode && displayAnimation && (
            <div className="mt-6 pt-6 border-t border-night-700/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="status-indicator status-indicator-active" />
                  <span className="text-night-300">Active Animation</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-white font-medium">
                    {animationLabels[displayAnimation.animation] || displayAnimation.animation}
                  </span>
                  {displayAnimation.palette && (
                    <div className="flex gap-1">
                      {displayAnimation.palette.slice(0, 4).map((color, i) => (
                        <div
                          key={i}
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-8 text-night-500">
          <Cloud className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No weather data available</p>
          <p className="text-sm mt-1">Configure your location in settings</p>
        </div>
      )}
    </div>
  );
}
