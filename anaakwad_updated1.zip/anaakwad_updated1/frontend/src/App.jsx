import React, { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from './hooks/useWebSocket';
import { useApi } from './hooks/useApi';
import Header from './components/Header';
import WeatherStatus from './components/WeatherStatus';
import LightSelector from './components/LightSelector';
import WeatherMappings from './components/WeatherMappings';
import WeatherConditionsPanel from './components/WeatherConditionsPanel';
import AnimationControls from './components/AnimationControls';
import SetupWizard from './components/SetupWizard';
import SettingsPanel from './components/SettingsPanel';

export default function App() {
  const [showSetup, setShowSetup] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [config, setConfig] = useState(null);
  const [weather, setWeather] = useState(null);
  const [animation, setAnimation] = useState(null);
  const [lights, setLights] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedLights, setSelectedLights] = useState([]);
  const [weatherMode, setWeatherMode] = useState(false);
  const [bridgeConnected, setBridgeConnected] = useState(false);
  const [loading, setLoading] = useState(true);

  const api = useApi();

  // WebSocket message handler
  const handleMessage = useCallback((message) => {
    switch (message.type) {
      case 'state':
        setWeatherMode(message.data.weatherMode);
        setWeather(message.data.currentWeather);
        setAnimation(message.data.currentAnimation);
        setSelectedLights(message.data.selectedLights || []);
        setBridgeConnected(message.data.bridgeConnected);
        break;
      case 'weather':
        setWeather(message.data);
        break;
      case 'animation':
      case 'animationState':
        setAnimation(message.data);
        break;
      case 'weatherMode':
        setWeatherMode(message.data.enabled);
        break;
      case 'selectedLights':
        setSelectedLights(message.data.lights);
        break;
      case 'bridgeConnected':
        setBridgeConnected(message.data.connected);
        break;
    }
  }, []);

  const { connected: wsConnected } = useWebSocket(handleMessage);

  // Initial data fetch
  useEffect(() => {
    async function fetchInitialData() {
      try {
        const [configData, statusData, lightsData, groupsData] = await Promise.all([
          api.get('/api/config'),
          api.get('/api/hue/status'),
          api.get('/api/hue/lights').catch(() => []),
          api.get('/api/hue/groups').catch(() => [])
        ]);

        setConfig(configData);
        setBridgeConnected(statusData.connected);
        setLights(lightsData);
        setGroups(groupsData);
        setSelectedLights(configData.selectedLights || []);
        setWeatherMode(configData.weatherMode);

        // Check if setup is needed (based only on weather config)
        if (!configData.weatherApiKey || configData.weatherApiKey === '') {
          setShowSetup(true);
        }

        // Fetch current weather if available
        const weatherData = await api.get('/api/weather').catch(() => null);
        setWeather(weatherData);
      } catch (error) {
        console.error('Failed to fetch initial data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchInitialData();
  }, [api]);

  const handleToggleWeatherMode = async () => {
    try {
      const newMode = !weatherMode;
      await api.post('/api/weather-mode', { enabled: newMode });
      setWeatherMode(newMode);
    } catch (error) {
      console.error('Failed to toggle weather mode:', error);
    }
  };

  const handleSelectLights = async (lightIds) => {
    try {
      await api.post('/api/hue/lights/select', { lights: lightIds });
      setSelectedLights(lightIds);
    } catch (error) {
      console.error('Failed to select lights:', error);
    }
  };

  const handleSetupComplete = async () => {
    setShowSetup(false);
    // Refresh data
    const [statusData, lightsData, groupsData] = await Promise.all([
      api.get('/api/hue/status'),
      api.get('/api/hue/lights').catch(() => []),
      api.get('/api/hue/groups').catch(() => [])
    ]);
    setBridgeConnected(statusData.connected);
    setLights(lightsData);
    setGroups(groupsData);
  };

  const handleRefreshWeather = async () => {
    try {
      const data = await api.post('/api/weather/refresh');
      setWeather(data);
    } catch (error) {
      console.error('Failed to refresh weather:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="aurora-bg" />
        <div className="stars" />
        <div className="text-center relative z-10">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-ice-500/20 animate-pulse" />
          <p className="text-night-400 font-medium">Loading Anaakwad...</p>
        </div>
      </div>
    );
  }

  if (showSetup) {
    return (
      <SetupWizard
        onComplete={handleSetupComplete}
        config={config}
      />
    );
  }

  return (
    <div className="min-h-screen relative">
      {/* Background effects */}
      <div className="aurora-bg" />
      <div className="stars" />
      
      {/* Main content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Header
          weatherMode={weatherMode}
          onToggleWeatherMode={handleToggleWeatherMode}
          onOpenSettings={() => setShowSettings(true)}
          bridgeConnected={bridgeConnected}
          wsConnected={wsConnected}
        />

        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main status panel */}
          <div className="lg:col-span-2 space-y-6">
            <WeatherStatus
              weather={weather}
              animation={animation}
              weatherMode={weatherMode}
              onRefresh={handleRefreshWeather}
            />

            <WeatherConditionsPanel
              currentWeather={weather}
              currentAnimation={animation}
            />

            <WeatherMappings
              selectedLights={selectedLights}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <LightSelector
              lights={lights}
              groups={groups}
              selectedLights={selectedLights}
              onSelectLights={handleSelectLights}
            />

            <AnimationControls
              selectedLights={selectedLights}
              weatherMode={weatherMode}
              currentAnimation={animation}
            />
          </div>
        </div>
      </div>

      {/* Settings panel */}
      {showSettings && (
        <SettingsPanel
          onClose={() => setShowSettings(false)}
          config={config}
          onConfigUpdate={setConfig}
        />
      )}
    </div>
  );
}
