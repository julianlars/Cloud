import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Use absolute path for data directory
const DATA_DIR = process.env.CONFIG_PATH 
  ? path.dirname(process.env.CONFIG_PATH)
  : path.resolve(__dirname, '../../data');
const CONFIG_PATH = process.env.CONFIG_PATH || path.join(DATA_DIR, 'config.json');

export class ConfigStore {
  constructor() {
    this.ensureDataDir();
    this.config = this.loadConfig();
  }

  ensureDataDir() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        console.log(`Created data directory: ${DATA_DIR}`);
      }
    } catch (error) {
      console.error('Failed to create data directory:', error.message);
    }
  }

  loadConfig() {
    try {
      if (fs.existsSync(CONFIG_PATH)) {
        const data = fs.readFileSync(CONFIG_PATH, 'utf-8');
        const parsed = JSON.parse(data);
        console.log('Loaded config from:', CONFIG_PATH);
        return { ...this.getDefaultConfig(), ...parsed };
      }
    } catch (error) {
      console.error('Failed to load config:', error.message);
    }

    console.log('Using default config');
    return this.getDefaultConfig();
  }

  getDefaultConfig() {
    return {
      weatherMode: false,
      weatherProvider: 'openweathermap',
      weatherApiKey: process.env.WEATHER_API_KEY || '',
      latitude: process.env.LATITUDE || '',
      longitude: process.env.LONGITUDE || '',
      bridgeIp: '',
      hueUsername: '',
      selectedLights: [],
      selectedGroups: [],
      animationIntensity: 1.0,
      masterBrightness: 1.0,
      weatherMappings: this.getDefaultWeatherMappings(),
      customAnimations: {}
    };
  }

  saveConfig() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(this.config, null, 2));
    } catch (error) {
      console.error('Failed to save config:', error.message);
    }
  }

  get(key) {
    return this.config[key];
  }

  set(key, value) {
    this.config[key] = value;
    this.saveConfig();
  }

  getAll() {
    return { ...this.config };
  }

  setMultiple(updates) {
    Object.assign(this.config, updates);
    this.saveConfig();
  }

  getDefaultWeatherMappings() {
    return {
      rain: {
        name: 'Rain',
        palette: ['#1a365d', '#2c5282', '#4a6fa5', '#718096'],
        animation: 'rainPulse',
        intensity: 0.8
      },
      thunderstorm: {
        name: 'Thunderstorm',
        palette: ['#322659', '#44337a', '#553c9a', '#6b46c1'],
        animation: 'lightningFlash',
        intensity: 1.0
      },
      snow: {
        name: 'Snow',
        palette: ['#bee3f8', '#e2e8f0', '#edf2f7', '#ffffff'],
        animation: 'snowDrift',
        intensity: 0.6
      },
      cloudy: {
        name: 'Cloudy',
        palette: ['#4a5568', '#718096', '#a0aec0', '#cbd5e0'],
        animation: 'cloudDrift',
        intensity: 0.5
      },
      hot: {
        name: 'Hot / Heatwave',
        palette: ['#c53030', '#dd6b20', '#d69e2e', '#ed8936'],
        animation: 'heatRipple',
        intensity: 0.7
      },
      windy: {
        name: 'Windy',
        palette: ['#0d9488', '#14b8a6', '#2dd4bf', '#5eead4'],
        animation: 'windSway',
        intensity: 0.8
      },
      fog: {
        name: 'Fog',
        palette: ['#a0aec0', '#cbd5e0', '#e2e8f0', '#edf2f7'],
        animation: 'mistFade',
        intensity: 0.3
      },
      clear: {
        name: 'Clear Day',
        palette: ['#faf5ea', '#fef3c7', '#fde68a', '#ffffff'],
        animation: 'none',
        intensity: 1.0
      },
      sunrise: {
        name: 'Sunrise',
        palette: ['#7c2d12', '#c2410c', '#ea580c', '#f97316', '#fbbf24', '#fef3c7'],
        animation: 'sunriseRamp',
        intensity: 1.0
      },
      sunset: {
        name: 'Sunset',
        palette: ['#f97316', '#ea580c', '#dc2626', '#9a3412', '#7c2d12'],
        animation: 'candleFlicker',
        intensity: 0.9
      }
    };
  }

  getWeatherMapping(condition) {
    const mappings = this.config.weatherMappings || this.getDefaultWeatherMappings();
    return mappings[condition] || mappings.clear;
  }

  updateWeatherMapping(condition, mapping) {
    if (!this.config.weatherMappings) {
      this.config.weatherMappings = this.getDefaultWeatherMappings();
    }
    this.config.weatherMappings[condition] = {
      ...this.config.weatherMappings[condition],
      ...mapping
    };
    this.saveConfig();
  }
}
