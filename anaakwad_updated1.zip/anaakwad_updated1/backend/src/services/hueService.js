import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

export class HueService {
  constructor(configStore) {
    this.configStore = configStore;
    this.bridge = null;
    this.api = null;
    this.lights = new Map();
    this.groups = new Map();
    this.connected = false;
    this.manualOverride = new Set(); // Track lights with manual override
  }

  async initialize() {
    const bridgeIp = this.configStore.get('bridgeIp');
    const username = this.configStore.get('hueUsername');

    if (bridgeIp && username) {
      try {
        await this.connect(bridgeIp, username);
      } catch (error) {
        console.error('Failed to connect to saved bridge:', error.message);
      }
    }
  }

  isConnected() {
    return this.connected;
  }

  async discoverBridges() {
    try {
      // Use Hue discovery portal
      const response = await axios.get('https://discovery.meethue.com/', {
        timeout: 10000
      });
      return response.data.map(bridge => ({
        id: bridge.id,
        ip: bridge.internalipaddress
      }));
    } catch (error) {
      console.error('Bridge discovery failed:', error.message);
      return [];
    }
  }

  async registerBridge(bridgeIp) {
    try {
      const response = await axios.post(`http://${bridgeIp}/api`, {
        devicetype: `anaakwad#${uuidv4().substring(0, 8)}`
      }, { timeout: 30000 });

      const result = response.data[0];
      
      if (result.error) {
        if (result.error.type === 101) {
          throw new Error('LINK_BUTTON_NOT_PRESSED');
        }
        throw new Error(result.error.description);
      }

      if (result.success) {
        const username = result.success.username;
        this.configStore.set('bridgeIp', bridgeIp);
        this.configStore.set('hueUsername', username);
        await this.connect(bridgeIp, username);
        return { success: true, username };
      }

      throw new Error('Unknown registration error');
    } catch (error) {
      throw error;
    }
  }

  async connect(bridgeIp, username) {
    this.bridge = { ip: bridgeIp, username };
    
    // Test connection
    const response = await axios.get(
      `http://${bridgeIp}/api/${username}/lights`,
      { timeout: 5000 }
    );

    if (response.data.error) {
      throw new Error(response.data.error.description);
    }

    this.connected = true;
    await this.refreshLights();
    await this.refreshGroups();
    
    console.log(`Connected to Hue bridge at ${bridgeIp}`);
    return true;
  }

  async refreshLights() {
    if (!this.connected) return [];

    const response = await axios.get(
      `http://${this.bridge.ip}/api/${this.bridge.username}/lights`
    );

    this.lights.clear();
    
    for (const [id, light] of Object.entries(response.data)) {
      this.lights.set(id, {
        id,
        name: light.name,
        type: light.type,
        modelid: light.modelid,
        state: light.state,
        capabilities: this.getLightCapabilities(light)
      });
    }

    return Array.from(this.lights.values());
  }

  async refreshGroups() {
    if (!this.connected) return [];

    const response = await axios.get(
      `http://${this.bridge.ip}/api/${this.bridge.username}/groups`
    );

    this.groups.clear();
    
    for (const [id, group] of Object.entries(response.data)) {
      this.groups.set(id, {
        id,
        name: group.name,
        type: group.type,
        lights: group.lights,
        state: group.state
      });
    }

    return Array.from(this.groups.values());
  }

  getLightCapabilities(light) {
    const caps = {
      color: false,
      colorTemp: false,
      dimming: false
    };

    if (light.type.includes('Color') || light.type.includes('Extended')) {
      caps.color = true;
      caps.colorTemp = true;
      caps.dimming = true;
    } else if (light.type.includes('White')) {
      caps.colorTemp = true;
      caps.dimming = true;
    } else if (light.type.includes('Dimmable')) {
      caps.dimming = true;
    }

    return caps;
  }

  getLights() {
    return Array.from(this.lights.values());
  }

  getGroups() {
    return Array.from(this.groups.values());
  }

  // Convert HSV to Hue's xy color space
  hsvToXY(h, s, v) {
    // Convert HSV to RGB
    const c = v * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = v - c;
    
    let r, g, b;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    
    r += m; g += m; b += m;

    // Apply gamma correction
    r = r > 0.04045 ? Math.pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
    g = g > 0.04045 ? Math.pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
    b = b > 0.04045 ? Math.pow((b + 0.055) / 1.055, 2.4) : b / 12.92;

    // Convert to XYZ
    const X = r * 0.649926 + g * 0.103455 + b * 0.197109;
    const Y = r * 0.234327 + g * 0.743075 + b * 0.022598;
    const Z = r * 0.0000000 + g * 0.053077 + b * 1.035763;

    const sum = X + Y + Z;
    if (sum === 0) return [0.33, 0.33];

    return [X / sum, Y / sum];
  }

  // Convert RGB to XY
  rgbToXY(r, g, b) {
    r = r / 255;
    g = g / 255;
    b = b / 255;

    r = r > 0.04045 ? Math.pow((r + 0.055) / 1.055, 2.4) : r / 12.92;
    g = g > 0.04045 ? Math.pow((g + 0.055) / 1.055, 2.4) : g / 12.92;
    b = b > 0.04045 ? Math.pow((b + 0.055) / 1.055, 2.4) : b / 12.92;

    const X = r * 0.649926 + g * 0.103455 + b * 0.197109;
    const Y = r * 0.234327 + g * 0.743075 + b * 0.022598;
    const Z = r * 0.0000000 + g * 0.053077 + b * 1.035763;

    const sum = X + Y + Z;
    if (sum === 0) return [0.33, 0.33];

    return [X / sum, Y / sum];
  }

  async setLightState(lightId, state) {
    if (!this.connected) return false;
    if (this.manualOverride.has(lightId)) return false;

    try {
      const hueState = {};
      
      if (state.on !== undefined) hueState.on = state.on;
      if (state.brightness !== undefined) hueState.bri = Math.round(state.brightness * 254);
      if (state.transitionTime !== undefined) hueState.transitiontime = Math.round(state.transitionTime / 100);
      
      if (state.color) {
        if (state.color.xy) {
          hueState.xy = state.color.xy;
        } else if (state.color.rgb) {
          hueState.xy = this.rgbToXY(...state.color.rgb);
        } else if (state.color.hsv) {
          hueState.xy = this.hsvToXY(...state.color.hsv);
        } else if (state.color.ct) {
          // Color temperature in mireds (153-500)
          hueState.ct = Math.max(153, Math.min(500, state.color.ct));
        }
      }

      await axios.put(
        `http://${this.bridge.ip}/api/${this.bridge.username}/lights/${lightId}/state`,
        hueState
      );

      return true;
    } catch (error) {
      console.error(`Failed to set light ${lightId} state:`, error.message);
      return false;
    }
  }

  async setMultipleLightsState(lightIds, state) {
    const promises = lightIds.map(id => this.setLightState(id, state));
    return Promise.all(promises);
  }

  async setGroupState(groupId, state) {
    if (!this.connected) return false;

    try {
      const hueState = {};
      
      if (state.on !== undefined) hueState.on = state.on;
      if (state.brightness !== undefined) hueState.bri = Math.round(state.brightness * 254);
      if (state.transitionTime !== undefined) hueState.transitiontime = Math.round(state.transitionTime / 100);
      
      if (state.color) {
        if (state.color.xy) {
          hueState.xy = state.color.xy;
        } else if (state.color.rgb) {
          hueState.xy = this.rgbToXY(...state.color.rgb);
        }
      }

      await axios.put(
        `http://${this.bridge.ip}/api/${this.bridge.username}/groups/${groupId}/action`,
        hueState
      );

      return true;
    } catch (error) {
      console.error(`Failed to set group ${groupId} state:`, error.message);
      return false;
    }
  }

  setManualOverride(lightId, override = true) {
    if (override) {
      this.manualOverride.add(lightId);
    } else {
      this.manualOverride.delete(lightId);
    }
  }

  clearAllOverrides() {
    this.manualOverride.clear();
  }

  hasOverride(lightId) {
    return this.manualOverride.has(lightId);
  }

  async getCurrentLightState(lightId) {
    if (!this.connected) return null;

    try {
      const response = await axios.get(
        `http://${this.bridge.ip}/api/${this.bridge.username}/lights/${lightId}`
      );
      return response.data.state;
    } catch (error) {
      console.error(`Failed to get light ${lightId} state:`, error.message);
      return null;
    }
  }
}
