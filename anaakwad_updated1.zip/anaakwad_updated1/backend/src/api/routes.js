export function setupRoutes(app, services) {
  const {
    hueService,
    weatherService,
    animationEngine,
    configStore,
    broadcast,
    startWeatherPolling,
    stopWeatherPolling
  } = services;

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: Date.now() });
  });

  // === Configuration ===
  
  app.get('/api/config', (req, res) => {
    try {
      const config = configStore.getAll();
      // Don't expose sensitive keys
      const safeConfig = {
        ...config,
        weatherApiKey: config.weatherApiKey ? '***configured***' : '',
        hueUsername: config.hueUsername ? '***configured***' : ''
      };
      res.json(safeConfig);
    } catch (error) {
      console.error('GET /api/config error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/config', (req, res) => {
    try {
      const updates = req.body;
      // Prevent overwriting credentials if not provided
      if (updates.weatherApiKey === '***configured***') {
        delete updates.weatherApiKey;
      }
      if (updates.hueUsername === '***configured***') {
        delete updates.hueUsername;
      }
      configStore.setMultiple(updates);
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/config error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Weather Mode ===

  app.get('/api/weather-mode', (req, res) => {
    try {
      res.json({ enabled: configStore.get('weatherMode') });
    } catch (error) {
      console.error('GET /api/weather-mode error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/weather-mode', async (req, res) => {
    try {
      const { enabled } = req.body;
      configStore.set('weatherMode', enabled);

      if (enabled) {
        hueService.clearAllOverrides();
        await startWeatherPolling();
        animationEngine.start();
        
        // Trigger immediate weather fetch
        const weather = await weatherService.fetchWeather();
        if (weather) {
          animationEngine.setWeather(weather);
        }
      } else {
        stopWeatherPolling();
        animationEngine.stop();
      }

      broadcast('weatherMode', { enabled });
      res.json({ success: true, enabled });
    } catch (error) {
      console.error('POST /api/weather-mode error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  
// === Weather ===

app.get('/api/weather', (req, res) => {
  try {
    const current = weatherService.getCurrentWeather();
    res.json(current || { status: 'no-data' });
  } catch (error) {
    console.error('GET /api/weather error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/weather/mappings', (req, res) => {
  try {
    const mappings = configStore.get('weatherMappings') || {};
    res.json(mappings);
  } catch (error) {
    console.error('GET /api/weather/mappings error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/weather/config', (req, res) => {
  try {
    const { mappings, cycleMode, customDurationMs } = req.body || {};
    if (mappings && typeof mappings === 'object') {
      configStore.set('weatherMappings', mappings);
    }
    if (cycleMode) {
      configStore.set('cycleMode', cycleMode);
    }
    if (typeof customDurationMs === 'number') {
      configStore.set('customCycleDurationMs', customDurationMs);
    }

    animationEngine.setCycleSettings({
      cycleMode: cycleMode || configStore.get('cycleMode'),
      customDurationMs: typeof customDurationMs === 'number'
        ? customDurationMs
        : configStore.get('customCycleDurationMs')
    });

    res.json({ success: true });
  } catch (error) {
    console.error('PUT /api/weather/config error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/weather/config', (req, res) => {
  try {
    const mappings = configStore.get('weatherMappings') || {};
    const cycleMode = configStore.get('cycleMode') || 'static';
    const customDurationMs = configStore.get('customCycleDurationMs') || 60000;
    res.json({ mappings, cycleMode, customDurationMs });
  } catch (error) {
    console.error('GET /api/weather/config error:', error);
    res.status(500).json({ error: error.message });
  }
});


  app.post('/api/weather/refresh', async (req, res) => {
    try {
      const weather = await weatherService.fetchWeather();
      if (weather && configStore.get('weatherMode')) {
        animationEngine.setWeather(weather);
      }
      res.json(weather || { error: 'Failed to fetch weather' });
    } catch (error) {
      console.error('POST /api/weather/refresh error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/weather/mappings', (req, res) => {
    try {
      const mappings = configStore.get('weatherMappings') || configStore.getDefaultWeatherMappings();
      res.json(mappings);
    } catch (error) {
      console.error('GET /api/weather/mappings error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/weather/mappings/:condition', (req, res) => {
    try {
      const { condition } = req.params;
      const mapping = req.body;
      configStore.updateWeatherMapping(condition, mapping);
      res.json({ success: true });
    } catch (error) {
      console.error('PUT /api/weather/mappings error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Hue Bridge ===

  app.get('/api/hue/status', (req, res) => {
    try {
      res.json({
        connected: hueService.isConnected(),
        bridgeIp: configStore.get('bridgeIp') || null
      });
    } catch (error) {
      console.error('GET /api/hue/status error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/hue/discover', async (req, res) => {
    try {
      const bridges = await hueService.discoverBridges();
      res.json(bridges);
    } catch (error) {
      console.error('GET /api/hue/discover error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  

app.post('/api/hue/reconnect', async (req, res) => {
  try {
    await hueService.initialize();
    broadcast('bridgeConnected', { connected: hueService.isConnected(), bridgeIp: configStore.get('bridgeIp') || null });
    res.json({ success: true, connected: hueService.isConnected() });
  } catch (error) {
    console.error('POST /api/hue/reconnect error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/hue/register', async (req, res) => {
    const { bridgeIp } = req.body;
    try {
      const result = await hueService.registerBridge(bridgeIp);
      broadcast('bridgeConnected', { connected: true, bridgeIp });
      res.json(result);
    } catch (error) {
      console.error('POST /api/hue/register error:', error);
      if (error.message === 'LINK_BUTTON_NOT_PRESSED') {
        res.status(400).json({ 
          error: 'LINK_BUTTON_NOT_PRESSED',
          message: 'Please press the link button on your Hue bridge and try again'
        });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.post('/api/hue/connect', async (req, res) => {
    const { bridgeIp, username } = req.body;
    try {
      await hueService.connect(bridgeIp, username);
      configStore.set('bridgeIp', bridgeIp);
      configStore.set('hueUsername', username);
      broadcast('bridgeConnected', { connected: true, bridgeIp });
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/hue/connect error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Lights ===

  app.get('/api/hue/lights', async (req, res) => {
    try {
      const lights = await hueService.refreshLights();
      res.json(lights);
    } catch (error) {
      console.error('GET /api/hue/lights error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/hue/groups', async (req, res) => {
    try {
      const groups = await hueService.refreshGroups();
      res.json(groups);
    } catch (error) {
      console.error('GET /api/hue/groups error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/hue/lights/select', (req, res) => {
    try {
      const { lights } = req.body;
      configStore.set('selectedLights', lights);
      broadcast('selectedLights', { lights });
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/hue/lights/select error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/hue/lights/:id/state', async (req, res) => {
    const { id } = req.params;
    const state = req.body;
    try {
      await hueService.setLightState(id, state);
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/hue/lights/:id/state error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Animation ===

  app.get('/api/animation/status', (req, res) => {
    try {
      res.json(animationEngine.getCurrentAnimation() || { running: false });
    } catch (error) {
      console.error('GET /api/animation/status error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/animation/preview', async (req, res) => {
    const { condition } = req.body;
    const lights = configStore.get('selectedLights') || [];
    try {
      await animationEngine.previewCondition(condition, lights);
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/animation/preview error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/animation/override', async (req, res) => {
    const { scene } = req.body;
    const lights = configStore.get('selectedLights') || [];
    try {
      await animationEngine.applyManualScene(scene, lights);
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/animation/override error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/animation/clear-override', (req, res) => {
    try {
      hueService.clearAllOverrides();
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/animation/clear-override error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/animation/intensity', (req, res) => {
    try {
      const { intensity } = req.body;
      configStore.set('animationIntensity', Math.max(0, Math.min(1, intensity)));
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/animation/intensity error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Master Brightness ===

  app.get('/api/brightness', (req, res) => {
    try {
      const brightness = configStore.get('masterBrightness') || 1.0;
      res.json({ brightness });
    } catch (error) {
      console.error('GET /api/brightness error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/brightness', (req, res) => {
    try {
      const { brightness } = req.body;
      const clampedBrightness = Math.max(0.05, Math.min(1, brightness));
      configStore.set('masterBrightness', clampedBrightness);
      // Notify animation engine of brightness change
      animationEngine.setMasterBrightness(clampedBrightness);
      broadcast('brightness', { brightness: clampedBrightness });
      res.json({ success: true, brightness: clampedBrightness });
    } catch (error) {
      console.error('POST /api/brightness error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === Location ===

  app.post('/api/location', (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      configStore.set('latitude', latitude);
      configStore.set('longitude', longitude);
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/location error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // === API Keys ===

  app.post('/api/keys/weather', (req, res) => {
    try {
      const { apiKey, provider } = req.body;
      configStore.set('weatherApiKey', apiKey);
      if (provider) {
        configStore.set('weatherProvider', provider);
      }
      res.json({ success: true });
    } catch (error) {
      console.error('POST /api/keys/weather error:', error);
      res.status(500).json({ error: error.message });
    }
  });
}
